import type { ExerciseDef, MuscleGroup } from '../types';

export const GROUPS: MuscleGroup[] = [
  'Pecho',
  'Espalda',
  'Piernas',
  'Hombros',
  'Brazos',
  'Core',
  'Full Body',
];

export const GROUP_COLORS: Record<MuscleGroup, string> = {
  Pecho: '#ff6b2c',
  Espalda: '#5aa7e6',
  Piernas: '#3ddc97',
  Hombros: '#ffc65c',
  Brazos: '#f47fb0',
  Core: '#b692f6',
  'Full Body': '#97a49a',
};

export const EQUIPMENT = [
  'Barra',
  'Mancuernas',
  'Máquina',
  'Polea',
  'Peso corporal',
  'Kettlebell',
  'Otro',
];

const ex = (
  id: string,
  name: string,
  group: MuscleGroup,
  equipment: string,
  extra?: Partial<ExerciseDef>,
): ExerciseDef => ({ id, name, group, equipment, ...extra });

export const EXERCISES: ExerciseDef[] = [
  // Pecho
  ex('press-banca', 'Press de banca', 'Pecho', 'Barra'),
  ex('press-inclinado-barra', 'Press inclinado con barra', 'Pecho', 'Barra'),
  ex('press-inclinado-man', 'Press inclinado con mancuernas', 'Pecho', 'Mancuernas'),
  ex('press-plano-man', 'Press plano con mancuernas', 'Pecho', 'Mancuernas'),
  ex('aperturas-man', 'Aperturas con mancuernas', 'Pecho', 'Mancuernas'),
  ex('cruces-polea', 'Cruces en polea', 'Pecho', 'Polea'),
  ex('press-maquina', 'Press en máquina', 'Pecho', 'Máquina'),
  ex('flexiones', 'Flexiones', 'Pecho', 'Peso corporal', { bodyweight: true }),
  ex('fondos-paralelas', 'Fondos en paralelas', 'Pecho', 'Peso corporal', { bodyweight: true }),
  // Espalda
  ex('dominadas', 'Dominadas', 'Espalda', 'Peso corporal', { bodyweight: true }),
  ex('remo-barra', 'Remo con barra', 'Espalda', 'Barra'),
  ex('remo-man', 'Remo con mancuerna', 'Espalda', 'Mancuernas'),
  ex('remo-polea', 'Remo en polea baja', 'Espalda', 'Polea'),
  ex('jalon-pecho', 'Jalón al pecho', 'Espalda', 'Polea'),
  ex('remo-tbar', 'Remo en barra T', 'Espalda', 'Barra'),
  ex('face-pull', 'Face pull', 'Espalda', 'Polea'),
  ex('pull-over-polea', 'Pull-over en polea', 'Espalda', 'Polea'),
  ex('peso-muerto', 'Peso muerto', 'Espalda', 'Barra'),
  // Piernas
  ex('sentadilla', 'Sentadilla con barra', 'Piernas', 'Barra'),
  ex('sentadilla-frontal', 'Sentadilla frontal', 'Piernas', 'Barra'),
  ex('prensa', 'Prensa de piernas', 'Piernas', 'Máquina'),
  ex('peso-muerto-rumano', 'Peso muerto rumano', 'Piernas', 'Barra'),
  ex('hip-thrust', 'Hip thrust', 'Piernas', 'Barra'),
  ex('zancadas', 'Zancadas con mancuernas', 'Piernas', 'Mancuernas'),
  ex('sentadilla-bulgara', 'Sentadilla búlgara', 'Piernas', 'Mancuernas'),
  ex('extension-cuadriceps', 'Extensión de cuádriceps', 'Piernas', 'Máquina'),
  ex('curl-femoral', 'Curl femoral', 'Piernas', 'Máquina'),
  ex('elevacion-talones', 'Elevación de talones', 'Piernas', 'Máquina'),
  // Hombros
  ex('press-militar', 'Press militar con barra', 'Hombros', 'Barra'),
  ex('press-man-hombro', 'Press de hombro con mancuernas', 'Hombros', 'Mancuernas'),
  ex('press-arnold', 'Press Arnold', 'Hombros', 'Mancuernas'),
  ex('elevaciones-laterales', 'Elevaciones laterales', 'Hombros', 'Mancuernas'),
  ex('elevaciones-frontales', 'Elevaciones frontales', 'Hombros', 'Mancuernas'),
  ex('pajaros', 'Pájaros (posterior)', 'Hombros', 'Mancuernas'),
  ex('encogimientos', 'Encogimientos de trapecio', 'Hombros', 'Mancuernas'),
  ex('remo-menton', 'Remo al mentón', 'Hombros', 'Barra'),
  // Brazos
  ex('curl-barra', 'Curl con barra', 'Brazos', 'Barra'),
  ex('curl-martillo', 'Curl martillo', 'Brazos', 'Mancuernas'),
  ex('curl-scott', 'Curl en banco Scott', 'Brazos', 'Barra'),
  ex('curl-concentrado', 'Curl concentrado', 'Brazos', 'Mancuernas'),
  ex('curl-polea', 'Curl en polea', 'Brazos', 'Polea'),
  ex('extension-triceps-polea', 'Extensión de tríceps en polea', 'Brazos', 'Polea'),
  ex('press-frances', 'Press francés', 'Brazos', 'Barra'),
  ex('fondos-banco', 'Fondos entre bancos', 'Brazos', 'Peso corporal', { bodyweight: true }),
  ex('extension-copa', 'Extensión copa', 'Brazos', 'Mancuernas'),
  // Core
  ex('plancha', 'Plancha', 'Core', 'Peso corporal', { bodyweight: true, unit: 'seg' }),
  ex('plancha-lateral', 'Plancha lateral', 'Core', 'Peso corporal', { bodyweight: true, unit: 'seg' }),
  ex('crunch', 'Crunch abdominal', 'Core', 'Peso corporal', { bodyweight: true }),
  ex('elevacion-piernas', 'Elevación de piernas', 'Core', 'Peso corporal', { bodyweight: true }),
  ex('rueda-abdominal', 'Rueda abdominal', 'Core', 'Otro', { bodyweight: true }),
  ex('russian-twist', 'Russian twist', 'Core', 'Kettlebell'),
  ex('crunch-polea', 'Crunch en polea', 'Core', 'Polea'),
  // Full body
  ex('burpees', 'Burpees', 'Full Body', 'Peso corporal', { bodyweight: true }),
  ex('kb-swing', 'Kettlebell swing', 'Full Body', 'Kettlebell'),
  ex('thrusters', 'Thrusters', 'Full Body', 'Barra'),
  ex('clean-press', 'Clean and press', 'Full Body', 'Barra'),
  ex('paseo-granjero', 'Paseo del granjero', 'Full Body', 'Mancuernas'),
];
