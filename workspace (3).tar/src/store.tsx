import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type {
  ActiveSession,
  ExerciseDef,
  MuscleGroup,
  RestTimerState,
  SessionExercise,
  Settings,
  SetEntry,
  ToastMsg,
  Unit,
  WorkoutSession,
} from './types';
import { EXERCISES } from './data/exercises';
import { dateKey, detectPRs, lastPerformance, uid } from './lib/stats';
import { generateSample } from './lib/sample';

const LS_KEY = 'forja.v1';

interface Persisted {
  sessions: WorkoutSession[];
  custom: ExerciseDef[];
  settings: Settings;
  active: ActiveSession | null;
}

const DEFAULTS: Persisted = {
  sessions: [],
  custom: [],
  settings: { weeklyGoal: 4, defaultRest: 90 },
  active: null,
};

function load(): Persisted {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return DEFAULTS;
    const p = JSON.parse(raw) as Partial<Persisted>;
    return {
      sessions: Array.isArray(p.sessions) ? p.sessions : [],
      custom: Array.isArray(p.custom) ? p.custom : [],
      settings: {
        weeklyGoal: p.settings?.weeklyGoal ?? 4,
        defaultRest: p.settings?.defaultRest ?? 90,
      },
      active: p.active ?? null,
    };
  } catch {
    return DEFAULTS;
  }
}

export interface GymApi {
  sessions: WorkoutSession[];
  custom: ExerciseDef[];
  settings: Settings;
  active: ActiveSession | null;
  allExercises: ExerciseDef[];
  exMap: Record<string, ExerciseDef>;
  rest: RestTimerState | null;
  toasts: ToastMsg[];
  toast: (text: string, kind?: ToastMsg['kind']) => void;
  dismissToast: (id: string) => void;
  startSession: (plan?: SessionExercise[]) => void;
  cancelSession: () => void;
  addExercise: (exerciseId: string) => void;
  removeExercise: (exId: string) => void;
  addSet: (exId: string) => void;
  removeSet: (exId: string, setId: string) => void;
  updateSet: (exId: string, setId: string, patch: Partial<SetEntry>) => void;
  toggleSet: (exId: string, setId: string) => void;
  setExBodyweight: (exId: string, bw: boolean) => void;
  finishSession: (meta: { energy?: number; notes?: string }) => WorkoutSession | null;
  deleteSession: (id: string) => void;
  planFromSession: (s: WorkoutSession) => SessionExercise[];
  repeatSession: (id: string) => void;
  addCustom: (d: { name: string; group: MuscleGroup; equipment: string; bodyweight: boolean; unit: Unit }) => string;
  deleteCustom: (id: string) => boolean;
  setSettings: (patch: Partial<Settings>) => void;
  loadSample: () => void;
  clearAll: () => void;
  exportData: () => void;
  importData: (file: File) => void;
  startRest: (total: number, label?: string) => void;
  stopRest: () => void;
  bumpRest: (delta: number) => void;
}

const Ctx = createContext<GymApi | null>(null);

export function GymProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<Persisted>(load);
  const [rest, setRest] = useState<RestTimerState | null>(null);
  const [toasts, setToasts] = useState<ToastMsg[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(data));
    } catch {
      /* almacenamiento lleno o bloqueado */
    }
  }, [data]);

  const allExercises = useMemo(() => [...EXERCISES, ...data.custom], [data.custom]);
  const exMap = useMemo(
    () => Object.fromEntries(allExercises.map((e) => [e.id, e])) as Record<string, ExerciseDef>,
    [allExercises],
  );

  const toast = (text: string, kind: ToastMsg['kind'] = 'ok') => {
    const id = uid();
    setToasts((t) => [...t.slice(-3), { id, text, kind }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  };
  const dismissToast = (id: string) => setToasts((t) => t.filter((x) => x.id !== id));

  /* ---------- construcción de planes ---------- */
  const buildExercise = (exerciseId: string): SessionExercise => {
    const def = exMap[exerciseId];
    const bw = !!def?.bodyweight;
    const last = lastPerformance(data.sessions, exerciseId);
    const sets: SetEntry[] = [];
    if (last && last.entries.length) {
      last.entries.forEach((e, i) =>
        sets.push({ id: uid() + i, reps: e.reps, weight: bw ? 0 : e.weight, bodyweight: bw, done: false }),
      );
    } else {
      for (let i = 0; i < 3; i++)
        sets.push({ id: uid() + i, reps: bw && def?.unit === 'seg' ? 30 : 8, weight: bw ? 0 : 20, bodyweight: bw, done: false });
    }
    return { id: uid(), exerciseId, bodyweight: bw, sets };
  };

  const startSession = (plan?: SessionExercise[]) => {
    setData((d) => ({
      ...d,
      active: { id: uid(), startedAt: Date.now(), exercises: plan ?? [] },
    }));
  };

  const cancelSession = () => {
    setData((d) => ({ ...d, active: null }));
    setRest(null);
  };

  const addExercise = (exerciseId: string) => {
    setData((d) => {
      if (!d.active) return d;
      return {
        ...d,
        active: { ...d.active, exercises: [...d.active.exercises, buildExercise(exerciseId)] },
      };
    });
  };

  const removeExercise = (exId: string) =>
    setData((d) =>
      d.active
        ? { ...d, active: { ...d.active, exercises: d.active.exercises.filter((e) => e.id !== exId) } }
        : d,
    );

  const addSet = (exId: string) =>
    setData((d) => {
      if (!d.active) return d;
      return {
        ...d,
        active: {
          ...d.active,
          exercises: d.active.exercises.map((e) => {
            if (e.id !== exId) return e;
            const last = e.sets[e.sets.length - 1];
            const copy: SetEntry = last
              ? { ...last, id: uid(), done: false, completedAt: undefined, restAfter: undefined }
              : { id: uid(), reps: 8, weight: e.bodyweight ? 0 : 20, bodyweight: e.bodyweight, done: false };
            return { ...e, sets: [...e.sets, copy] };
          }),
        },
      };
    });

  const removeSet = (exId: string, setId: string) =>
    setData((d) => {
      if (!d.active) return d;
      return {
        ...d,
        active: {
          ...d.active,
          exercises: d.active.exercises.map((e) =>
            e.id === exId && e.sets.length > 1
              ? { ...e, sets: e.sets.filter((s) => s.id !== setId) }
              : e,
          ),
        },
      };
    });

  const updateSet = (exId: string, setId: string, patch: Partial<SetEntry>) =>
    setData((d) => {
      if (!d.active) return d;
      return {
        ...d,
        active: {
          ...d.active,
          exercises: d.active.exercises.map((e) =>
            e.id === exId
              ? { ...e, sets: e.sets.map((s) => (s.id === setId ? { ...s, ...patch } : s)) }
              : e,
          ),
        },
      };
    });

  const setExBodyweight = (exId: string, bw: boolean) =>
    setData((d) => {
      if (!d.active) return d;
      return {
        ...d,
        active: {
          ...d.active,
          exercises: d.active.exercises.map((e) => {
            if (e.id !== exId) return e;
            // al volver al modo "con peso", recupera el último peso conocido
            const refill = !bw ? (lastPerformance(d.sessions, e.exerciseId)?.best?.weight ?? 0) : 0;
            return {
              ...e,
              bodyweight: bw,
              sets: e.sets.map((s) => ({
                ...s,
                bodyweight: bw,
                weight: bw ? 0 : s.weight > 0 ? s.weight : refill,
              })),
            };
          }),
        },
      };
    });

  const startRest = (total: number, label?: string) =>
    setRest({ endsAt: Date.now() + total * 1000, total, label });
  const stopRest = () => setRest(null);
  const bumpRest = (delta: number) =>
    setRest((r) =>
      r
        ? {
            ...r,
            endsAt: r.endsAt + delta * 1000,
            total: Math.max(10, r.total + delta),
          }
        : r,
    );

  const toggleSet = (exId: string, setId: string) => {
    const ex = data.active?.exercises.find((e) => e.id === exId);
    const set = ex?.sets.find((s) => s.id === setId);
    if (!ex || !set) return;
    const now = Date.now();

    if (!set.done) {
      // descanso registrado: tiempo desde la última serie completada del ejercicio
      const prevTimes = ex.sets
        .filter((s) => s.id !== setId && s.done && s.completedAt)
        .map((s) => s.completedAt as number);
      const restAfter = prevTimes.length ? Math.max(0, Math.round((now - Math.max(...prevTimes)) / 1000)) : undefined;

      setData((d) => {
        if (!d.active) return d;
        return {
          ...d,
          active: {
            ...d.active,
            exercises: d.active.exercises.map((e) =>
              e.id === exId
                ? {
                    ...e,
                    sets: e.sets.map((s) =>
                      s.id === setId ? { ...s, done: true, completedAt: now, restAfter } : s,
                    ),
                  }
                : e,
            ),
          },
        };
      });

      const def = exMap[ex.exerciseId];
      const idx = ex.sets.findIndex((s) => s.id === setId);
      startRest(data.settings.defaultRest, `${def?.name ?? 'Ejercicio'} · Serie ${idx + 1}`);
    } else {
      setData((d) => {
        if (!d.active) return d;
        return {
          ...d,
          active: {
            ...d.active,
            exercises: d.active.exercises.map((e) =>
              e.id === exId
                ? {
                    ...e,
                    sets: e.sets.map((s) =>
                      s.id === setId ? { ...s, done: false, completedAt: undefined, restAfter: undefined } : s,
                    ),
                  }
                : e,
            ),
          },
        };
      });
    }
  };

  const planFromSession = (s: WorkoutSession): SessionExercise[] =>
    s.exercises.map((e) => ({
      id: uid(),
      exerciseId: e.exerciseId,
      bodyweight: e.bodyweight,
      sets: e.sets.map((st) => ({
        id: uid(),
        reps: st.reps,
        weight: st.weight,
        bodyweight: st.bodyweight,
        done: false,
      })),
    }));

  const repeatSession = (id: string) => {
    const s = data.sessions.find((x) => x.id === id);
    if (!s) return;
    startSession(planFromSession(s));
  };

  const finishSession = (meta: { energy?: number; notes?: string }): WorkoutSession | null => {
    if (!data.active) return null;
    const now = Date.now();
    const exercises: SessionExercise[] = data.active.exercises
      .map((e) => ({
        ...e,
        sets: e.sets.filter((s) => s.done).map((s) => ({ ...s, completedAt: undefined })),
      }))
      .filter((e) => e.sets.length > 0);
    if (!exercises.length) {
      toast('Marca al menos una serie como completada.', 'warn');
      return null;
    }
    const session: WorkoutSession = {
      id: data.active.id,
      date: dateKey(new Date(data.active.startedAt)),
      startTime: data.active.startedAt,
      endTime: now,
      exercises,
      energy: meta.energy,
      notes: meta.notes?.trim() || undefined,
      prs: detectPRs(data.sessions, exercises, exMap),
    };
    setData((d) => ({ ...d, sessions: [session, ...d.sessions], active: null }));
    setRest(null);
    return session;
  };

  const deleteSession = (id: string) =>
    setData((d) => ({ ...d, sessions: d.sessions.filter((s) => s.id !== id) }));

  const addCustom = (c: { name: string; group: MuscleGroup; equipment: string; bodyweight: boolean; unit: Unit }) => {
    const id =
      c.name
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '') +
      '-' +
      uid().slice(0, 4);
    setData((d) => ({
      ...d,
      custom: [...d.custom, { id, name: c.name, group: c.group, equipment: c.equipment, bodyweight: c.bodyweight, unit: c.unit, custom: true }],
    }));
    toast(`«${c.name}» añadido a tu biblioteca.`);
    return id;
  };

  const deleteCustom = (id: string): boolean => {
    const inUse = data.sessions.some((s) => s.exercises.some((e) => e.exerciseId === id));
    if (inUse) {
      toast('No se puede borrar: se usa en sesiones guardadas.', 'warn');
      return false;
    }
    setData((d) => ({ ...d, custom: d.custom.filter((e) => e.id !== id) }));
    return true;
  };

  const setSettings = (patch: Partial<Settings>) =>
    setData((d) => ({ ...d, settings: { ...d.settings, ...patch } }));

  const loadSample = () => {
    setData((d) => ({ ...d, sessions: generateSample() }));
    toast('10 semanas de ejemplo cargadas. ¡Explora tu progreso!', 'info');
  };

  const clearAll = () => {
    setData({ ...DEFAULTS });
    setRest(null);
    toast('Todos los datos han sido borrados.', 'warn');
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify({ app: 'forja', version: 1, ...data }, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `forja-backup-${dateKey(new Date())}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('Copia de seguridad descargada.');
  };

  const importData = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const p = JSON.parse(String(reader.result)) as Partial<Persisted>;
        if (!Array.isArray(p.sessions)) throw new Error('formato');
        setData({
          sessions: p.sessions,
          custom: Array.isArray(p.custom) ? p.custom : [],
          settings: {
            weeklyGoal: p.settings?.weeklyGoal ?? 4,
            defaultRest: p.settings?.defaultRest ?? 90,
          },
          active: null,
        });
        toast(`Datos importados: ${p.sessions.length} sesiones.`);
      } catch {
        toast('El archivo no tiene un formato válido.', 'warn');
      }
    };
    reader.readAsText(file);
  };

  const api: GymApi = {
    sessions: data.sessions,
    custom: data.custom,
    settings: data.settings,
    active: data.active,
    allExercises,
    exMap,
    rest,
    toasts,
    toast,
    dismissToast,
    startSession,
    cancelSession,
    addExercise,
    removeExercise,
    addSet,
    removeSet,
    updateSet,
    toggleSet,
    setExBodyweight,
    finishSession,
    deleteSession,
    planFromSession,
    repeatSession,
    addCustom,
    deleteCustom,
    setSettings,
    loadSample,
    clearAll,
    exportData,
    importData,
    startRest,
    stopRest,
    bumpRest,
  };

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useGym(): GymApi {
  const v = useContext(Ctx);
  if (!v) throw new Error('useGym debe usarse dentro de GymProvider');
  return v;
}
