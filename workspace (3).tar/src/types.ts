export type MuscleGroup =
  | 'Pecho'
  | 'Espalda'
  | 'Piernas'
  | 'Hombros'
  | 'Brazos'
  | 'Core'
  | 'Full Body';

export type Unit = 'reps' | 'seg';

export interface ExerciseDef {
  id: string;
  name: string;
  group: MuscleGroup;
  equipment: string;
  bodyweight?: boolean;
  unit?: Unit;
  custom?: boolean;
}

export interface SetEntry {
  id: string;
  reps: number;
  weight: number; // kg · 0 = peso corporal
  bodyweight: boolean;
  done: boolean;
  completedAt?: number;
  restAfter?: number; // segundos descansados ANTES de esta serie
}

export interface SessionExercise {
  id: string;
  exerciseId: string;
  bodyweight: boolean;
  sets: SetEntry[];
}

export type PRKind = 'peso' | 'e1rm' | 'reps';

export interface PR {
  exerciseId: string;
  exerciseName: string;
  kind: PRKind;
  value: number;
  prev?: number;
}

export interface WorkoutSession {
  id: string;
  date: string; // yyyy-mm-dd
  startTime: number;
  endTime: number;
  exercises: SessionExercise[];
  energy?: number; // 1..5
  notes?: string;
  prs: PR[];
}

export interface ActiveSession {
  id: string;
  startedAt: number;
  exercises: SessionExercise[];
}

export interface Settings {
  weeklyGoal: number;
  defaultRest: number; // segundos
}

export interface RestTimerState {
  endsAt: number;
  total: number;
  label?: string;
}

export interface ToastMsg {
  id: string;
  text: string;
  kind: 'ok' | 'info' | 'warn' | 'pr';
}

export type Tab = 'inicio' | 'entrenar' | 'historial' | 'progreso' | 'ejercicios';
