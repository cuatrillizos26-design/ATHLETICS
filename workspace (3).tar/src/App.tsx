import { useState } from 'react';
import type { Tab } from './types';
import { GymProvider } from './store';
import { Layout } from './components/Layout';
import { RestTimer } from './components/RestTimer';
import { Dashboard } from './views/Dashboard';
import { ActiveSessionView } from './views/ActiveSession';
import { History } from './views/History';
import { Progress } from './views/Progress';
import { Exercises } from './views/Exercises';

function Shell() {
  const [tab, setTab] = useState<Tab>('inicio');
  return (
    <Layout tab={tab} setTab={setTab}>
      <div key={tab} className="anim-fade-up">
        {tab === 'inicio' && <Dashboard go={setTab} />}
        {tab === 'entrenar' && <ActiveSessionView go={setTab} />}
        {tab === 'historial' && <History go={setTab} />}
        {tab === 'progreso' && <Progress go={setTab} />}
        {tab === 'ejercicios' && <Exercises />}
      </div>
      <RestTimer />
    </Layout>
  );
}

export default function App() {
  return (
    <GymProvider>
      <Shell />
    </GymProvider>
  );
}
