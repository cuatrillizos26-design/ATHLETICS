import type {
  ExerciseDef,
  MuscleGroup,
  PR,
  SessionExercise,
  SetEntry,
  WorkoutSession,
} from '../types';

/* ---------------- utils ---------------- */
export const uid = () =>
  Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

export const pad = (n: number) => String(n).padStart(2, '0');

export const dateKey = (d: Date) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const cap = (s: string) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);

const nf1 = new Intl.NumberFormat('es-ES', { maximumFractionDigits: 1 });
const nf0 = new Intl.NumberFormat('es-ES', { maximumFractionDigits: 0 });

export const fmtNum = (n: number) => nf1.format(Math.round(n * 10) / 10);
export const fmtInt = (n: number) => nf0.format(Math.round(n));
export const fmtKg = (n: number) => `${fmtNum(n)} kg`;
export const fmtClock = (sec: number) => {
  const s = Math.max(0, Math.round(sec));
  return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
};
export const fmtDur = (ms: number) => {
  const m = Math.max(1, Math.round(ms / 60000));
  if (m < 60) return `${m} min`;
  return `${Math.floor(m / 60)} h ${pad(m % 60)} min`;
};
export const fmtDateShort = (iso: string) =>
  new Date(iso + 'T12:00:00').toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
export const fmtDateLong = (iso: string) =>
  cap(new Date(iso + 'T12:00:00').toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' }));
export const fmtMonthYear = (iso: string) =>
  cap(new Date(iso + 'T12:00:00').toLocaleDateString('es-ES', { month: 'long', year: 'numeric' }));
export const weekdayShort = (iso: string) =>
  cap(new Date(iso + 'T12:00:00').toLocaleDateString('es-ES', { weekday: 'short' }));

export const daysSince = (iso: string) => {
  const d = new Date(iso + 'T12:00:00');
  const now = new Date();
  now.setHours(12, 0, 0, 0);
  return Math.max(0, Math.round((now.getTime() - d.getTime()) / 86400000));
};
export const daysSinceLabel = (iso: string) => {
  const d = daysSince(iso);
  if (d === 0) return 'hoy';
  if (d === 1) return 'ayer';
  return `hace ${d} días`;
};

/* ---------------- per-set / per-exercise ---------------- */
export const e1rm = (w: number, r: number) => (w > 0 && r > 0 ? w * (1 + r / 30) : 0);

export const doneSets = (ex: SessionExercise) => ex.sets.filter((s) => s.done);

export const bestWeightedSet = (ex: SessionExercise): SetEntry | null => {
  let best: SetEntry | null = null;
  for (const s of ex.sets) {
    if (!s.done || s.bodyweight || s.weight <= 0) continue;
    if (!best || s.weight > best.weight || (s.weight === best.weight && s.reps > best.reps)) best = s;
  }
  return best;
};

export const bestE1rmOf = (ex: SessionExercise): number => {
  let best = 0;
  for (const s of ex.sets) {
    if (!s.done || s.bodyweight) continue;
    best = Math.max(best, e1rm(s.weight, s.reps));
  }
  return best;
};

export const maxRepsOf = (ex: SessionExercise): number => {
  let best = 0;
  for (const s of ex.sets) if (s.done) best = Math.max(best, s.reps);
  return best;
};

export const exVolume = (ex: SessionExercise) =>
  ex.sets.reduce((a, s) => (s.done && !s.bodyweight ? a + s.weight * s.reps : a), 0);

export const exReps = (ex: SessionExercise) =>
  ex.sets.reduce((a, s) => (s.done ? a + s.reps : a), 0);

export const setLabel = (s: SetEntry) =>
  s.bodyweight || s.weight <= 0 ? `PC × ${s.reps}` : `${fmtNum(s.weight)} × ${s.reps}`;

/* ---------------- per-session ---------------- */
export const sessionVolume = (s: WorkoutSession) => s.exercises.reduce((a, e) => a + exVolume(e), 0);
export const countSets = (s: WorkoutSession) =>
  s.exercises.reduce((a, e) => a + doneSets(e).length, 0);

export const avgRestOf = (s: WorkoutSession): number | null => {
  const rests: number[] = [];
  for (const e of s.exercises) for (const st of e.sets) if (st.done && st.restAfter) rests.push(st.restAfter);
  if (!rests.length) return null;
  return rests.reduce((a, b) => a + b, 0) / rests.length;
};

export interface Intensity {
  label: string;
  cls: string;
}
export const intensityOf = (volumeKg: number, durationMin: number): Intensity => {
  const d = volumeKg / Math.max(durationMin, 1);
  if (volumeKg < 300) return { label: 'Ligero', cls: 'text-steel bg-steel/10' };
  if (d < 75) return { label: 'Suave', cls: 'text-steel bg-steel/10' };
  if (d < 155) return { label: 'Moderado', cls: 'text-mint bg-mint/10' };
  if (d < 250) return { label: 'Intenso', cls: 'text-gold bg-gold/10' };
  return { label: 'Brutal', cls: 'text-ember bg-ember/10' };
};

/* ---------------- history series ---------------- */
export interface ExPoint {
  date: string;
  label: string;
  maxW: number;
  e1: number;
  vol: number;
  reps: number;
  sets: number;
}

export const exerciseSeries = (sessions: WorkoutSession[], exerciseId: string): ExPoint[] => {
  const pts: ExPoint[] = [];
  const sorted = [...sessions].sort((a, b) => a.startTime - b.startTime);
  for (const s of sorted) {
    const e = s.exercises.find((x) => x.exerciseId === exerciseId);
    if (!e || !doneSets(e).length) continue;
    const bw = bestWeightedSet(e);
    pts.push({
      date: s.date,
      label: fmtDateShort(s.date),
      maxW: bw ? bw.weight : 0,
      e1: Math.round(bestE1rmOf(e) * 10) / 10,
      vol: Math.round(exVolume(e)),
      reps: exReps(e),
      sets: doneSets(e).length,
    });
  }
  return pts;
};

export interface LastPerf {
  date: string;
  entries: { weight: number; reps: number; bodyweight: boolean }[];
  best: SetEntry | null;
  volume: number;
  bodyweight: boolean;
}

export const lastPerformance = (
  sessions: WorkoutSession[],
  exerciseId: string,
): LastPerf | null => {
  const sorted = [...sessions].sort((a, b) => b.startTime - a.startTime);
  for (const s of sorted) {
    const e = s.exercises.find((x) => x.exerciseId === exerciseId);
    if (!e || !doneSets(e).length) continue;
    return {
      date: s.date,
      entries: doneSets(e).map((st) => ({ weight: st.weight, reps: st.reps, bodyweight: st.bodyweight })),
      best: bestWeightedSet(e),
      volume: exVolume(e),
      bodyweight: e.bodyweight,
    };
  }
  return null;
};

/* ---------------- weeks ---------------- */
export const mondayOf = (d: Date) => {
  const x = new Date(d);
  x.setHours(12, 0, 0, 0);
  const day = (x.getDay() + 6) % 7; // lunes = 0
  x.setDate(x.getDate() - day);
  return x;
};

export interface WeekVol {
  key: string;
  label: string;
  total: number;
  groups: Partial<Record<MuscleGroup, number>>;
  sessions: number;
}

export const weeklyVolume = (
  sessions: WorkoutSession[],
  exMap: Record<string, ExerciseDef>,
  weeks = 8,
): WeekVol[] => {
  const now = mondayOf(new Date());
  const out: WeekVol[] = [];
  for (let i = weeks - 1; i >= 0; i--) {
    const mon = new Date(now);
    mon.setDate(mon.getDate() - i * 7);
    const sun = new Date(mon);
    sun.setDate(sun.getDate() + 7);
    const wk: WeekVol = {
      key: dateKey(mon),
      label: mon.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' }),
      total: 0,
      groups: {},
      sessions: 0,
    };
    for (const s of sessions) {
      if (s.startTime >= mon.getTime() && s.startTime < sun.getTime()) {
        wk.sessions++;
        for (const e of s.exercises) {
          const v = exVolume(e);
          wk.total += v;
          const g = exMap[e.exerciseId]?.group;
          if (g && v > 0) wk.groups[g] = (wk.groups[g] ?? 0) + v;
        }
      }
    }
    out.push(wk);
  }
  return out;
};

export const sessionsThisWeek = (sessions: WorkoutSession[]) => {
  const mon = mondayOf(new Date());
  return sessions.filter((s) => s.startTime >= mon.getTime());
};

export const streakWeeks = (sessions: WorkoutSession[]): number => {
  if (!sessions.length) return 0;
  const set = new Set(sessions.map((s) => dateKey(mondayOf(new Date(s.startTime)))));
  let cur = mondayOf(new Date());
  if (!set.has(dateKey(cur))) {
    cur.setDate(cur.getDate() - 7); // la semana en curso aún no corta la racha
    if (!set.has(dateKey(cur))) return 0;
  }
  let n = 0;
  while (set.has(dateKey(cur))) {
    n++;
    cur.setDate(cur.getDate() - 7);
  }
  return n;
};

/* ---------------- PRs ---------------- */
export const detectPRs = (
  prev: WorkoutSession[],
  exercises: SessionExercise[],
  exMap: Record<string, ExerciseDef>,
): PR[] => {
  const prs: PR[] = [];
  for (const e of exercises) {
    const done = doneSets(e);
    if (!done.length) continue;
    const def = exMap[e.exerciseId];
    const name = def?.name ?? e.exerciseId;

    let pastBestW = 0;
    let pastBestE1 = 0;
    let pastBestReps = 0;
    let hasPast = false;
    for (const s of prev) {
      const pe = s.exercises.find((x) => x.exerciseId === e.exerciseId);
      if (!pe) continue;
      hasPast = true;
      const bw = bestWeightedSet(pe);
      if (bw) pastBestW = Math.max(pastBestW, bw.weight);
      pastBestE1 = Math.max(pastBestE1, bestE1rmOf(pe));
      pastBestReps = Math.max(pastBestReps, maxRepsOf(pe));
    }

    if (e.bodyweight) {
      const reps = maxRepsOf(e);
      if (reps > 0 && reps > pastBestReps)
        prs.push({
          exerciseId: e.exerciseId,
          exerciseName: name,
          kind: 'reps',
          value: reps,
          prev: hasPast && pastBestReps > 0 ? pastBestReps : undefined,
        });
      continue;
    }

    const bw = bestWeightedSet(e);
    if (bw && bw.weight > pastBestW)
      prs.push({
        exerciseId: e.exerciseId,
        exerciseName: name,
        kind: 'peso',
        value: bw.weight,
        prev: hasPast && pastBestW > 0 ? pastBestW : undefined,
      });
    const e1 = bestE1rmOf(e);
    if (e1 > 0 && e1 > pastBestE1 + 0.01)
      prs.push({
        exerciseId: e.exerciseId,
        exerciseName: name,
        kind: 'e1rm',
        value: Math.round(e1 * 10) / 10,
        prev: hasPast && pastBestE1 > 0 ? Math.round(pastBestE1 * 10) / 10 : undefined,
      });
  }
  return prs;
};

export const prLabel = (pr: PR) =>
  pr.kind === 'peso'
    ? `Peso máx · ${fmtKg(pr.value)}`
    : pr.kind === 'e1rm'
      ? `1RM estimado · ${fmtKg(pr.value)}`
      : `Récord de repeticiones · ${pr.value}`;

export interface PRWithDate extends PR {
  date: string;
  sessionId: string;
}
export const allPRs = (sessions: WorkoutSession[]): PRWithDate[] =>
  sessions
    .flatMap((s) => s.prs.map((p) => ({ ...p, date: s.date, sessionId: s.id })))
    .sort((a, b) => (a.date < b.date ? 1 : -1));

/* ---------------- muscle balance ---------------- */
export const muscleBalance = (
  sessions: WorkoutSession[],
  exMap: Record<string, ExerciseDef>,
): { group: MuscleGroup; kg: number }[] => {
  const mon = mondayOf(new Date());
  const acc: Partial<Record<MuscleGroup, number>> = {};
  for (const s of sessions) {
    if (s.startTime < mon.getTime()) continue;
    for (const e of s.exercises) {
      const g = exMap[e.exerciseId]?.group;
      const v = exVolume(e);
      if (g) acc[g] = (acc[g] ?? 0) + v;
    }
  }
  return (Object.entries(acc) as [MuscleGroup, number][])
    .map(([group, kg]) => ({ group, kg }))
    .sort((a, b) => b.kg - a.kg);
};
