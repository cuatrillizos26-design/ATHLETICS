import type { SessionExercise, SetEntry, WorkoutSession } from '../types';
import { dateKey, detectPRs, uid } from './stats';
import { EXERCISES } from '../data/exercises';

// generador determinista
const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const exMap = Object.fromEntries(EXERCISES.map((e) => [e.id, e]));

interface Plan {
  id: string;
  base: number;
  inc: number; // kg por semana
  sets: number;
  reps: [number, number];
  bw?: boolean;
  rest: [number, number];
}

const PUSH: Plan[] = [
  { id: 'press-banca', base: 60, inc: 1.5, sets: 4, reps: [6, 9], rest: [120, 170] },
  { id: 'press-inclinado-man', base: 22, inc: 0.6, sets: 4, reps: [8, 11], rest: [90, 130] },
  { id: 'press-militar', base: 35, inc: 1, sets: 3, reps: [7, 10], rest: [100, 140] },
  { id: 'cruces-polea', base: 15, inc: 0.5, sets: 3, reps: [10, 14], rest: [60, 90] },
  { id: 'fondos-paralelas', base: 8, inc: 0.35, sets: 3, reps: [7, 11], bw: true, rest: [80, 110] },
  { id: 'extension-triceps-polea', base: 25, inc: 0.8, sets: 3, reps: [10, 13], rest: [60, 90] },
];
const PULL: Plan[] = [
  { id: 'peso-muerto', base: 100, inc: 2.5, sets: 4, reps: [5, 7], rest: [150, 200] },
  { id: 'dominadas', base: 5, inc: 0.35, sets: 4, reps: [4, 9], bw: true, rest: [100, 140] },
  { id: 'remo-barra', base: 55, inc: 1.4, sets: 4, reps: [8, 10], rest: [100, 140] },
  { id: 'jalon-pecho', base: 55, inc: 1.4, sets: 3, reps: [9, 12], rest: [80, 110] },
  { id: 'face-pull', base: 20, inc: 0.5, sets: 3, reps: [12, 16], rest: [60, 80] },
  { id: 'curl-barra', base: 20, inc: 0.5, sets: 3, reps: [9, 12], rest: [60, 90] },
];
const LEGS: Plan[] = [
  { id: 'sentadilla', base: 80, inc: 2, sets: 4, reps: [6, 9], rest: [140, 190] },
  { id: 'prensa', base: 140, inc: 5, sets: 4, reps: [9, 12], rest: [110, 150] },
  { id: 'peso-muerto-rumano', base: 70, inc: 1.8, sets: 3, reps: [8, 11], rest: [100, 140] },
  { id: 'hip-thrust', base: 80, inc: 2.2, sets: 3, reps: [8, 11], rest: [100, 140] },
  { id: 'extension-cuadriceps', base: 35, inc: 1, sets: 3, reps: [10, 14], rest: [60, 90] },
  { id: 'plancha', base: 45, inc: 3, sets: 3, reps: [40, 60], bw: true, rest: [45, 70] },
];

const NOTES = [
  'Buenas sensaciones, el calentamiento nuevo me funciona.',
  'Costó arrancar, pero las últimas series salieron sólidas.',
  'Subí el descanso a 2 min en el básico y lo noté.',
  'Algo de prisa hoy, sesión más corta de lo normal.',
  'Energía a tope, casi saco una repetición más en la última.',
  '',
  '',
];

const round25 = (n: number) => Math.round(n / 2.5) * 2.5;

export function generateSample(): WorkoutSession[] {
  const rnd = mulberry32(20260214);
  const sessions: WorkoutSession[] = [];
  const routines = [PUSH, PULL, LEGS];
  const today = new Date();
  today.setHours(12, 0, 0, 0);

  for (let w = 9; w >= 0; w--) {
    const monday = new Date(today);
    const dow = (monday.getDay() + 6) % 7;
    monday.setDate(monday.getDate() - dow - w * 7);

    [0, 2, 4].forEach((offset, ri) => {
      if (w === 9 && offset === 4) return; // la semana actual puede estar empezando
      const day = new Date(monday);
      day.setDate(day.getDate() + offset);
      if (day.getTime() > today.getTime() - 3600e3) return;

      const plan = routines[(ri + (9 - w)) % 3];
      const weeksIn = 9 - w;
      const start = new Date(day);
      start.setHours(18, 20 + Math.floor(rnd() * 25), 0, 0);
      let clock = start.getTime();

      const exercises: SessionExercise[] = plan.map((p) => {
        const def = exMap[p.id];
        const sets: SetEntry[] = [];
        let prevDone: number | undefined;
        for (let i = 0; i < p.sets; i++) {
          clock += 40e3; // preparación
          if (prevDone) clock += Math.round((p.rest[0] + rnd() * (p.rest[1] - p.rest[0])) * 1000);
          const fatigue = i / p.sets;
          const reps = Math.max(
            1,
            Math.round(p.reps[0] + rnd() * (p.reps[1] - p.reps[0]) - fatigue * 2 + weeksIn * 0.12),
          );
          let weight = 0;
          if (!p.bw) {
            weight = round25(p.base + p.inc * weeksIn + (rnd() - 0.5) * 2 - fatigue * p.inc * 0.5);
            weight = Math.max(2.5, weight);
          } else if (def?.unit === 'seg') {
            weight = 0;
          }
          const set: SetEntry = {
            id: uid() + i,
            reps: p.bw && def?.unit !== 'seg' ? reps : p.bw ? Math.round(p.reps[0] + weeksIn * 1.5) : reps,
            weight,
            bodyweight: !!p.bw,
            done: true,
            completedAt: clock,
            restAfter: prevDone ? Math.round((clock - prevDone) / 1000) : undefined,
          };
          prevDone = clock;
          sets.push(set);
        }
        clock += 60e3;
        return { id: uid(), exerciseId: p.id, bodyweight: !!p.bw, sets };
      });

      const durationMin = 55 + Math.round(rnd() * 22);
      const session: WorkoutSession = {
        id: uid(),
        date: dateKey(day),
        startTime: start.getTime(),
        endTime: start.getTime() + durationMin * 60e3,
        exercises,
        energy: 3 + Math.floor(rnd() * 3),
        notes: NOTES[Math.floor(rnd() * NOTES.length)] || undefined,
        prs: [],
      };
      session.prs = detectPRs(sessions, session.exercises, exMap);
      sessions.push(session);
    });
  }
  return sessions.sort((a, b) => b.startTime - a.startTime);
}
