import { useMemo, useState } from 'react';
import type { MuscleGroup, Unit } from '../types';
import { useGym } from '../store';
import { EQUIPMENT, GROUPS } from '../data/exercises';
import { bestE1rmOf, bestWeightedSet, fmtNum, maxRepsOf } from '../lib/stats';
import { GroupChip, Modal, Reveal } from '../components/ui';
import { IBody, IDumbbell, IPlus, ISearch, ITrash } from '../components/icons';

interface ExStats {
  count: number;
  bestW: number;
  bestE1: number;
  bestReps: number;
}

export function Exercises() {
  const { allExercises, sessions, addCustom, deleteCustom } = useGym();
  const [q, setQ] = useState('');
  const [group, setGroup] = useState<MuscleGroup | 'todos'>('todos');
  const [modal, setModal] = useState(false);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  // formulario
  const [name, setName] = useState('');
  const [fGroup, setFGroup] = useState<MuscleGroup>('Pecho');
  const [fEquip, setFEquip] = useState('Barra');
  const [fBw, setFBw] = useState(false);
  const [fUnit, setFUnit] = useState<Unit>('reps');

  const stats = useMemo(() => {
    const m: Record<string, ExStats> = {};
    for (const s of sessions)
      for (const e of s.exercises) {
        const st = (m[e.exerciseId] ??= { count: 0, bestW: 0, bestE1: 0, bestReps: 0 });
        st.count++;
        const bw = bestWeightedSet(e);
        if (bw) st.bestW = Math.max(st.bestW, bw.weight);
        st.bestE1 = Math.max(st.bestE1, bestE1rmOf(e));
        st.bestReps = Math.max(st.bestReps, maxRepsOf(e));
      }
    return m;
  }, [sessions]);

  const list = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return allExercises
      .filter((e) => (group === 'todos' || e.group === group) && (!qq || e.name.toLowerCase().includes(qq)))
      .sort((a, b) => (stats[b.id]?.count ?? 0) - (stats[a.id]?.count ?? 0) || a.name.localeCompare(b.name));
  }, [allExercises, q, group, stats]);

  const submit = () => {
    if (!name.trim()) return;
    addCustom({
      name: name.trim(),
      group: fGroup,
      equipment: fBw ? 'Peso corporal' : fEquip,
      bodyweight: fBw,
      unit: fUnit,
    });
    setName('');
    setModal(false);
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="lbl mb-1">Biblioteca</p>
          <h1 className="display text-5xl md:text-6xl leading-none">Ejercicios</h1>
        </div>
        <button onClick={() => setModal(true)} className="btn btn-ember px-5 py-2.5">
          <IPlus width={17} height={17} /> Nuevo ejercicio
        </button>
      </header>

      <div className="space-y-3">
        <div className="relative">
          <ISearch width={16} height={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-mut2" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar en la biblioteca…" className="inp pl-9" />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {(['todos', ...GROUPS] as const).map((g) => (
            <button
              key={g}
              onClick={() => setGroup(g)}
              className={`chip cursor-pointer transition-colors ${
                group === g ? 'bg-ember/15 text-ember' : 'bg-raise text-mut hover:text-ink'
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-2.5">
        {list.map((e, i) => {
          const st = stats[e.id];
          return (
            <Reveal key={e.id} delay={Math.min(i * 30, 240)}>
              <div className="card p-4 flex items-center gap-3 hover:border-line2 transition-colors h-full">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm leading-tight">{e.name}</span>
                    {e.custom && <span className="chip bg-ember/12 text-ember">Tuyo</span>}
                    {e.bodyweight && (
                      <span className="chip bg-steel/10 text-steel">
                        <IBody width={11} height={11} /> PC
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <GroupChip group={e.group} />
                    <span className="text-[11px] font-bold text-mut2 uppercase tracking-wider">{e.equipment}</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  {st ? (
                    <>
                      <div className="display text-xl leading-none tabular-nums text-gold">
                        {e.bodyweight ? `${st.bestReps}${e.unit === 'seg' ? ' s' : ' reps'}` : st.bestW ? `${fmtNum(st.bestW)} kg` : `${fmtNum(st.bestReps)} reps`}
                      </div>
                      <div className="text-[10px] font-bold text-mut2 uppercase tracking-wider mt-1">
                        mejor · {st.count} {st.count === 1 ? 'sesión' : 'sesiones'}
                      </div>
                    </>
                  ) : (
                    <div className="text-[10px] font-bold text-mut2 uppercase tracking-wider">Sin registros</div>
                  )}
                </div>
                {e.custom && (
                  <button
                    onClick={() => {
                      if (confirmDel === e.id) {
                        deleteCustom(e.id);
                        setConfirmDel(null);
                      } else {
                        setConfirmDel(e.id);
                        window.setTimeout(() => setConfirmDel((c) => (c === e.id ? null : c)), 2600);
                      }
                    }}
                    className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                      confirmDel === e.id ? 'bg-danger text-[#2a0505]' : 'text-mut2 hover:text-danger hover:bg-danger/10'
                    }`}
                    title={confirmDel === e.id ? 'Pulsa otra vez para confirmar' : 'Eliminar ejercicio'}
                  >
                    {confirmDel === e.id ? <span className="text-[9px] font-extrabold uppercase">¿?</span> : <ITrash width={15} height={15} />}
                  </button>
                )}
              </div>
            </Reveal>
          );
        })}
      </div>

      {!list.length && (
        <p className="text-sm text-mut text-center py-10">No hay ejercicios que coincidan con la búsqueda.</p>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title="Nuevo ejercicio">
        <div className="space-y-3.5">
          <div>
            <span className="lbl mb-1.5">Nombre</span>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submit()}
              placeholder="p. ej. Press Landmine"
              className="inp"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <span className="lbl mb-1.5">Grupo muscular</span>
              <select value={fGroup} onChange={(e) => setFGroup(e.target.value as MuscleGroup)} className="inp">
                {GROUPS.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div>
              <span className="lbl mb-1.5">Material</span>
              <select value={fEquip} onChange={(e) => setFEquip(e.target.value)} className="inp" disabled={fBw}>
                {EQUIPMENT.map((eq) => <option key={eq} value={eq}>{eq}</option>)}
              </select>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setFBw(!fBw)}
              className={`chip py-2 px-3 cursor-pointer transition-colors ${fBw ? 'bg-steel/15 text-steel' : 'bg-raise text-mut hover:text-ink'}`}
            >
              <IBody width={13} height={13} /> {fBw ? 'Peso corporal' : 'Con peso externo'}
            </button>
            {fBw && (
              <select value={fUnit} onChange={(e) => setFUnit(e.target.value as Unit)} className="inp w-auto">
                <option value="reps">Se mide en repeticiones</option>
                <option value="seg">Se mide en segundos</option>
              </select>
            )}
          </div>
          <div className="flex gap-2.5 pt-1">
            <button onClick={() => setModal(false)} className="btn btn-ghost px-4 py-2.5 flex-1">Cancelar</button>
            <button onClick={submit} className="btn btn-ember px-4 py-2.5 flex-1" disabled={!name.trim()}>
              <IDumbbell width={17} height={17} /> Añadir a la biblioteca
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
