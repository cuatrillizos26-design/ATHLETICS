import { useEffect, useMemo, useState } from 'react';
import type { MuscleGroup, SessionExercise, SetEntry, Tab } from '../types';
import { useGym } from '../store';
import { GROUPS, EQUIPMENT } from '../data/exercises';
import {
  cap,
  daysSinceLabel,
  doneSets,
  exVolume,
  fmtClock,
  fmtDur,
  fmtInt,
  fmtNum,
  lastPerformance,
  setLabel,
} from '../lib/stats';
import { GroupChip, Modal, Stepper } from '../components/ui';
import {
  IBody,
  ICheck,
  IClock,
  IDumbbell,
  IFlame,
  INote,
  IPlus,
  IRepeat,
  ISearch,
  ITrash,
  IX,
  IBolt,
} from '../components/icons';

/* ================= Panel de inicio ================= */
function StartPanel({ go }: { go: (t: Tab) => void }) {
  const { sessions, startSession, repeatSession, planFromSession, exMap } = useGym();
  const sorted = useMemo(() => [...sessions].sort((a, b) => b.startTime - a.startTime), [sessions]);
  const last = sorted[0];

  return (
    <div className="max-w-2xl mx-auto anim-fade-up">
      <p className="lbl mb-1.5">Sesión de hoy</p>
      <h1 className="display text-6xl md:text-7xl leading-[0.9] mb-2">
        ¿Forjamos <span className="text-ember">hierro</span> hoy?
      </h1>
      <p className="text-mut font-semibold mb-8">
        Elige cómo empezar. Cada serie que completes quedará guardada con su peso, repeticiones y descanso.
      </p>

      <div className="space-y-3">
        <button
          onClick={() => { startSession(); go('entrenar'); }}
          className="card w-full p-5 flex items-center gap-4 text-left hover:border-ember/60 hover:bg-panel2 transition-all cursor-pointer group"
        >
          <span className="w-12 h-12 rounded-xl bg-ember/12 text-ember flex items-center justify-center shrink-0 group-hover:bg-ember group-hover:text-[#1c0d04] transition-colors">
            <IPlus width={24} height={24} />
          </span>
          <span>
            <span className="display text-2xl block leading-tight">Sesión en blanco</span>
            <span className="text-sm text-mut font-semibold">Empieza de cero y ve añadiendo ejercicios sobre la marcha.</span>
          </span>
        </button>

        {last && (
          <button
            onClick={() => { repeatSession(last.id); go('entrenar'); }}
            className="card w-full p-5 flex items-center gap-4 text-left hover:border-mint/60 hover:bg-panel2 transition-all cursor-pointer group"
          >
            <span className="w-12 h-12 rounded-xl bg-mint/12 text-mint flex items-center justify-center shrink-0 group-hover:bg-mint group-hover:text-[#042416] transition-colors">
              <IRepeat width={22} height={22} />
            </span>
            <span className="min-w-0">
              <span className="display text-2xl block leading-tight">Repetir último entrenamiento</span>
              <span className="text-sm text-mut font-semibold block truncate">
                {cap(daysSinceLabel(last.date))} ·{' '}
                {last.exercises.map((e) => exMap[e.exerciseId]?.name ?? 'Ejercicio').join(', ')}
              </span>
            </span>
          </button>
        )}

        {sorted.length > 1 && (
          <div className="card p-5">
            <span className="lbl mb-3">Usar como plantilla</span>
            <div className="space-y-1.5">
              {sorted.slice(1, 4).map((s) => (
                <div key={s.id} className="flex items-center gap-3 rounded-lg px-2 py-1.5 -mx-2 hover:bg-raise/60 transition-colors">
                  <IClock width={15} height={15} className="text-mut2 shrink-0" />
                  <span className="text-sm font-bold truncate flex-1">
                    {cap(daysSinceLabel(s.date))} · {s.exercises.length} ejercicios · {fmtInt(s.exercises.reduce((a, e) => a + exVolume(e), 0))} kg
                  </span>
                  <button
                    onClick={() => { startSession(planFromSession(s)); go('entrenar'); }}
                    className="btn btn-ghost px-3 py-1.5 text-[11px] uppercase tracking-wider shrink-0"
                  >
                    Usar
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= Fila de serie ================= */
function SetRow({
  s,
  i,
  ex,
  prevLabel,
  unitIsTime,
}: {
  s: SetEntry;
  i: number;
  ex: SessionExercise;
  prevLabel: string;
  unitIsTime: boolean;
}) {
  const { updateSet, toggleSet, removeSet, addSet } = useGym();
  const canRemove = ex.sets.length > 1;

  return (
    <div
      key={`${s.id}-${s.done}`}
      className={`grid grid-cols-[30px_minmax(0,1fr)_minmax(0,1fr)_36px_24px] sm:grid-cols-[34px_78px_minmax(0,1fr)_minmax(0,1fr)_38px_26px] gap-1.5 sm:gap-2 items-center rounded-lg px-2 py-1.5 transition-colors ${
        s.done ? 'set-flash text-mut' : 'hover:bg-raise/40'
      }`}
    >
      <span className={`display text-lg text-center ${s.done ? 'text-mint' : 'text-mut2'}`}>{i + 1}</span>
      <span className="hidden sm:block text-center text-xs font-bold text-mut2 truncate">{prevLabel}</span>

      {s.bodyweight ? (
        <span className="chip justify-center bg-steel/10 text-steel py-1.5">
          <IBody width={13} height={13} /> PC
        </span>
      ) : (
        <Stepper
          value={s.weight}
          onChange={(n) => updateSet(ex.id, s.id, { weight: n })}
          step={2.5}
          min={0}
          max={600}
          unit="kg"
        />
      )}

      <Stepper
        value={s.reps}
        onChange={(n) => updateSet(ex.id, s.id, { reps: Math.round(n) })}
        step={unitIsTime ? 5 : 1}
        min={0}
        max={unitIsTime ? 900 : 200}
        unit={unitIsTime ? 's' : undefined}
      />

      <button
        onClick={() => toggleSet(ex.id, s.id)}
        className={`w-9 h-9 rounded-lg flex items-center justify-center border transition-all cursor-pointer ${
          s.done
            ? 'bg-mint border-mint text-[#042416]'
            : 'border-line2 text-mut2 hover:border-mint/70 hover:text-mint'
        }`}
        aria-label={s.done ? 'Marcar serie como pendiente' : 'Marcar serie como completada'}
      >
        <ICheck width={17} height={17} strokeWidth={2.6} />
      </button>

      {canRemove ? (
        <button
          onClick={() => removeSet(ex.id, s.id)}
          className="w-6 h-6 rounded-md text-mut2 hover:text-danger hover:bg-danger/10 flex items-center justify-center transition-colors cursor-pointer"
          aria-label="Eliminar serie"
        >
          <IX width={13} height={13} />
        </button>
      ) : (
        <button
          onClick={() => addSet(ex.id)}
          className="w-6 h-6 rounded-md text-mut2 hover:text-ember hover:bg-ember/10 flex items-center justify-center transition-colors cursor-pointer"
          aria-label="Añadir serie"
        >
          <IPlus width={13} height={13} />
        </button>
      )}
    </div>
  );
}

/* ================= Tarjeta de ejercicio ================= */
function ExerciseCard({ ex, index }: { ex: SessionExercise; index: number }) {
  const { exMap, sessions, addSet, removeExercise, setExBodyweight } = useGym();
  const def = exMap[ex.exerciseId];
  const last = useMemo(() => lastPerformance(sessions, ex.exerciseId), [sessions, ex.exerciseId]);
  const unitIsTime = ex.bodyweight && def?.unit === 'seg';
  const done = doneSets(ex).length;

  const lastLabel = last
    ? last.bodyweight
      ? `PC × ${Math.max(...last.entries.map((e) => e.reps))}`
      : last.best
        ? setLabel(last.best)
        : '—'
    : null;

  return (
    <div className="card anim-fade-up overflow-hidden" style={{ animationDelay: `${index * 40}ms` }}>
      <div className="flex flex-wrap items-center gap-2 px-4 pt-4 pb-3">
        <span className="display text-ember text-xl w-7 text-center shrink-0">{index + 1}</span>
        <h3 className="font-bold text-base leading-tight">{def?.name ?? 'Ejercicio'}</h3>
        {def && <GroupChip group={def.group} />}
        <button
          onClick={() => setExBodyweight(ex.id, !ex.bodyweight)}
          className={`chip cursor-pointer transition-colors ${
            ex.bodyweight ? 'bg-steel/15 text-steel' : 'bg-raise text-mut hover:text-ink'
          }`}
          title="Alternar entre peso externo y peso corporal"
        >
          <IBody width={12} height={12} /> {ex.bodyweight ? 'Peso corporal' : 'Con peso'}
        </button>

        <span className="ml-auto flex items-center gap-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-mut2">
            {done}/{ex.sets.length} series
          </span>
          <button
            onClick={() => removeExercise(ex.id)}
            className="w-7 h-7 rounded-md text-mut2 hover:text-danger hover:bg-danger/10 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Quitar ejercicio"
          >
            <ITrash width={15} height={15} />
          </button>
        </span>
      </div>

      {last && (
        <div className="px-4 pb-3 -mt-1">
          <span className="text-[11px] font-bold text-mut2 uppercase tracking-wider">
            Última vez <span className="text-mut normal-case tracking-normal">({daysSinceLabel(last.date)})</span>:{' '}
            <span className="text-gold">{lastLabel}</span> · {last.entries.length} series
            {!ex.bodyweight && last.volume > 0 && <> · {fmtInt(last.volume)} kg</>}
          </span>
        </div>
      )}

      <div className="px-2.5 pb-3">
        <div className="grid grid-cols-[30px_minmax(0,1fr)_minmax(0,1fr)_36px_24px] sm:grid-cols-[34px_78px_minmax(0,1fr)_minmax(0,1fr)_38px_26px] gap-2 px-2 pb-1">
          <span className="lbl text-center">Nº</span>
          <span className="lbl text-center hidden sm:block">Anterior</span>
          <span className="lbl text-center">{ex.bodyweight ? 'Tipo' : 'Peso'}</span>
          <span className="lbl text-center">{unitIsTime ? 'Segs' : 'Reps'}</span>
          <span className="lbl text-center">✓</span>
          <span className="hidden sm:block" />
        </div>
        <div className="space-y-1">
          {ex.sets.map((s, i) => (
            <SetRow
              key={s.id}
              s={s}
              i={i}
              ex={ex}
              unitIsTime={unitIsTime}
              prevLabel={last && last.entries[i] ? (last.entries[i].bodyweight ? `PC×${last.entries[i].reps}` : `${fmtNum(last.entries[i].weight)}×${last.entries[i].reps}`) : '—'}
            />
          ))}
        </div>
        <button
          onClick={() => addSet(ex.id)}
          className="btn btn-ghost w-full mt-2 py-2 text-[11px] uppercase tracking-widest border-dashed"
        >
          <IPlus width={14} height={14} /> Añadir serie
        </button>
      </div>
    </div>
  );
}

/* ================= Selector de ejercicios ================= */
function ExercisePicker({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { allExercises, sessions, addExercise, addCustom, active, toast } = useGym();
  const [q, setQ] = useState('');
  const [group, setGroup] = useState<MuscleGroup | 'todos'>('todos');
  const [formOpen, setFormOpen] = useState(false);
  const [name, setName] = useState('');
  const [fGroup, setFGroup] = useState<MuscleGroup>('Pecho');
  const [fEquip, setFEquip] = useState('Barra');
  const [fBw, setFBw] = useState(false);

  const usage = useMemo(() => {
    const m: Record<string, number> = {};
    for (const s of sessions) for (const e of s.exercises) m[e.exerciseId] = (m[e.exerciseId] ?? 0) + 1;
    return m;
  }, [sessions]);

  const inSession = useMemo(
    () => new Set(active?.exercises.map((e) => e.exerciseId) ?? []),
    [active],
  );

  const list = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return allExercises
      .filter((e) => (group === 'todos' || e.group === group) && (!qq || e.name.toLowerCase().includes(qq)))
      .sort((a, b) => (usage[b.id] ?? 0) - (usage[a.id] ?? 0) || a.name.localeCompare(b.name));
  }, [allExercises, q, group, usage]);

  const createCustom = () => {
    if (!name.trim()) {
      toast('Escribe un nombre para el ejercicio.', 'warn');
      return;
    }
    const id = addCustom({ name: name.trim(), group: fGroup, equipment: fBw ? 'Peso corporal' : fEquip, bodyweight: fBw, unit: 'reps' });
    addExercise(id);
    setName('');
    setFormOpen(false);
    setQ('');
  };

  return (
    <Modal open={open} onClose={onClose} title="Añadir ejercicio" wide>
      <div className="relative mb-3">
        <ISearch width={16} height={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-mut2" />
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar ejercicio… (p. ej. press, remo, sentadilla)"
          className="inp pl-9"
        />
      </div>
      <div className="flex gap-1.5 flex-wrap mb-3">
        {(['todos', ...GROUPS] as const).map((g) => (
          <button
            key={g}
            onClick={() => setGroup(g)}
            className={`chip cursor-pointer transition-colors ${
              group === g ? 'bg-ember/15 text-ember' : 'bg-raise text-mut hover:text-ink'
            }`}
          >
            {g}
          </button>
        ))}
      </div>

      <div className="max-h-[46vh] overflow-y-auto -mx-2 px-2 space-y-1">
        {list.map((e) => {
          const added = inSession.has(e.id);
          return (
            <button
              key={e.id}
              disabled={added}
              onClick={() => addExercise(e.id)}
              className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors cursor-pointer ${
                added ? 'bg-mint/8 opacity-60 cursor-default' : 'hover:bg-raise/70'
              }`}
            >
              <span className="min-w-0 flex-1">
                <span className="font-bold text-sm block leading-tight">
                  {e.name}
                  {e.custom && <span className="chip bg-ember/12 text-ember ml-2 align-middle">Tuyo</span>}
                </span>
                <span className="text-[11px] font-bold text-mut2 uppercase tracking-wider">{e.equipment}</span>
              </span>
              {usage[e.id] ? (
                <span className="text-[11px] font-bold text-mut2 tabular-nums shrink-0">×{usage[e.id]}</span>
              ) : null}
              <GroupChip group={e.group} />
              {added ? (
                <ICheck width={17} height={17} className="text-mint shrink-0" />
              ) : (
                <IPlus width={17} height={17} className="text-ember shrink-0" />
              )}
            </button>
          );
        })}
        {!list.length && (
          <p className="text-sm text-mut text-center py-8">
            Sin resultados para «{q}». Pruébalo como ejercicio propio ↓
          </p>
        )}
      </div>

      <div className="border-t border-line mt-3 pt-3">
        {!formOpen ? (
          <button onClick={() => setFormOpen(true)} className="btn btn-ghost px-4 py-2 text-xs uppercase tracking-wider">
            <IPlus width={15} height={15} /> Crear ejercicio personalizado
          </button>
        ) : (
          <div className="grid sm:grid-cols-2 gap-2.5 anim-fade-up">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nombre (p. ej. Press Landmine)" className="inp sm:col-span-2" autoFocus />
            <select value={fGroup} onChange={(e) => setFGroup(e.target.value as MuscleGroup)} className="inp">
              {GROUPS.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
            <select value={fEquip} onChange={(e) => setFEquip(e.target.value)} className="inp" disabled={fBw}>
              {EQUIPMENT.map((e) => <option key={e} value={e}>{e}</option>)}
            </select>
            <button
              onClick={() => setFBw(!fBw)}
              className={`chip justify-center py-2 cursor-pointer transition-colors ${fBw ? 'bg-steel/15 text-steel' : 'bg-raise text-mut'}`}
            >
              <IBody width={13} height={13} /> {fBw ? 'Peso corporal' : 'Con peso externo'}
            </button>
            <button onClick={createCustom} className="btn btn-ember px-4 py-2 text-xs uppercase tracking-wider">
              Crear y añadir
            </button>
          </div>
        )}
      </div>
    </Modal>
  );
}

/* ================= Cierre de sesión ================= */
function FinishModal({ open, onClose, go }: { open: boolean; onClose: () => void; go: (t: Tab) => void }) {
  const { active, finishSession, toast } = useGym();
  const [energy, setEnergy] = useState(0);
  const [notes, setNotes] = useState('');

  if (!active) return null;
  const doneAll = active.exercises.flatMap((e) => doneSets(e));
  const vol = active.exercises.reduce((a, e) => a + exVolume(e), 0);
  const rests = active.exercises.flatMap((e) => e.sets.filter((s) => s.done && s.restAfter).map((s) => s.restAfter as number));
  const avgR = rests.length ? rests.reduce((a, b) => a + b, 0) / rests.length : null;

  const save = () => {
    const s = finishSession({ energy: energy || undefined, notes });
    if (!s) return;
    if (s.prs.length) toast(`¡${s.prs.length} récord${s.prs.length > 1 ? 's' : ''} personal${s.prs.length > 1 ? 'es' : ''} en esta sesión!`, 'pr');
    else toast('Sesión guardada en tu diario.');
    setEnergy(0);
    setNotes('');
    go('historial');
  };

  return (
    <Modal open={open} onClose={onClose} title="Cerrar sesión">
      <div className="grid grid-cols-3 gap-2.5 mb-5">
        <div className="rounded-lg bg-panel2 border border-line px-3 py-2.5 text-center">
          <div className="display text-2xl text-ember tabular-nums">{fmtInt(vol)}</div>
          <div className="lbl mt-0.5">kg volumen</div>
        </div>
        <div className="rounded-lg bg-panel2 border border-line px-3 py-2.5 text-center">
          <div className="display text-2xl tabular-nums">{doneAll.length}</div>
          <div className="lbl mt-0.5">series</div>
        </div>
        <div className="rounded-lg bg-panel2 border border-line px-3 py-2.5 text-center">
          <div className="display text-2xl tabular-nums">{fmtDur(Date.now() - active.startedAt)}</div>
          <div className="lbl mt-0.5">duración</div>
        </div>
      </div>

      {avgR !== null && (
        <p className="text-xs font-bold text-mut2 uppercase tracking-wider mb-4 flex items-center gap-1.5">
          <IClock width={14} height={14} /> Descanso medio entre series: <span className="text-mut">{fmtClock(avgR)}</span>
        </p>
      )}

      <div className="mb-4">
        <span className="lbl mb-2">¿Cómo te has sentido?</span>
        <div className="flex gap-1.5">
          {[1, 2, 3, 4, 5].map((i) => (
            <button
              key={i}
              onClick={() => setEnergy(i === energy ? 0 : i)}
              className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                i <= energy ? 'text-gold border-gold/40 bg-gold/8' : 'text-mut2 border-line hover:border-line2'
              }`}
              aria-label={`Energía ${i} de 5`}
            >
              <IBolt width={22} height={22} fill={i <= energy ? 'currentColor' : 'none'} />
            </button>
          ))}
          <span className="text-xs font-bold text-mut2 self-center ml-2 uppercase tracking-wider">
            {energy ? ['Muy fácil', 'Fácil', 'Bien', 'Duro', 'Al límite'][energy - 1] : 'Energía / esfuerzo'}
          </span>
        </div>
      </div>

      <div className="mb-5">
        <span className="lbl mb-2">Notas de la sesión</span>
        <div className="relative">
          <INote width={15} height={15} className="absolute left-3 top-3 text-mut2" />
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            placeholder="Sensaciones, técnica, cambios de rutina…"
            className="inp pl-9 resize-none"
          />
        </div>
      </div>

      <div className="flex gap-2.5">
        <button onClick={onClose} className="btn btn-ghost px-4 py-2.5 flex-1">Seguir entrenando</button>
        <button onClick={save} className="btn btn-ember px-4 py-2.5 flex-1">
          <ICheck width={17} height={17} /> Guardar sesión
        </button>
      </div>
    </Modal>
  );
}

/* ================= Vista principal ================= */
export function ActiveSessionView({ go }: { go: (t: Tab) => void }) {
  const { active, cancelSession } = useGym();
  const [picker, setPicker] = useState(false);
  const [finish, setFinish] = useState(false);
  const [cancelAsk, setCancelAsk] = useState(false);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [active]);

  if (!active) return <StartPanel go={go} />;

  const elapsed = now - active.startedAt;
  const doneCount = active.exercises.reduce((a, e) => a + doneSets(e).length, 0);

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <header className="card px-5 py-4 flex flex-wrap items-center gap-x-5 gap-y-3 sticky top-3 z-30 backdrop-blur bg-panel/92">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-mint pulse-dot" />
          <div>
            <div className="lbl">Sesión en curso</div>
            <div className="display text-3xl leading-none tabular-nums">{fmtClock(elapsed / 1000)}</div>
          </div>
        </div>
        <div className="text-xs font-bold text-mut2 uppercase tracking-wider">
          {active.exercises.length} ejercicios · <span className="text-mint">{doneCount}</span> series hechas
        </div>
        <div className="ml-auto flex gap-2">
          <button onClick={() => setCancelAsk(true)} className="btn btn-ghost px-3.5 py-2 text-xs uppercase tracking-wider">
            Descartar
          </button>
          <button onClick={() => setFinish(true)} className="btn btn-ember px-4 py-2 text-xs uppercase tracking-wider">
            <IFlame width={15} height={15} /> Finalizar
          </button>
        </div>
      </header>

      {active.exercises.map((e, i) => (
        <ExerciseCard key={e.id} ex={e} index={i} />
      ))}

      <button
        onClick={() => setPicker(true)}
        className="w-full rounded-xl border-2 border-dashed border-line2 text-mut hover:text-ember hover:border-ember/50 py-5 flex items-center justify-center gap-2 font-bold uppercase tracking-widest text-xs transition-colors cursor-pointer"
      >
        <IDumbbell width={18} height={18} /> Añadir ejercicio
      </button>

      {active.exercises.length === 0 && (
        <p className="text-center text-sm text-mut -mt-1">
          Tu sesión está vacía: añade el primer ejercicio para empezar a registrar series.
        </p>
      )}

      <div className="h-6" />

      <ExercisePicker open={picker} onClose={() => setPicker(false)} />
      <FinishModal open={finish} onClose={() => setFinish(false)} go={go} />

      <Modal open={cancelAsk} onClose={() => setCancelAsk(false)} title="¿Descartar sesión?">
        <p className="text-sm text-mut mb-5">
          Se perderá todo lo registrado en esta sesión ({doneCount} series). Las sesiones ya guardadas no se tocan.
        </p>
        <div className="flex gap-2.5">
          <button onClick={() => setCancelAsk(false)} className="btn btn-ghost px-4 py-2.5 flex-1">
            Seguir entrenando
          </button>
          <button
            onClick={() => { cancelSession(); setCancelAsk(false); }}
            className="btn btn-danger px-4 py-2.5 flex-1"
          >
            <ITrash width={16} height={16} /> Descartar
          </button>
        </div>
      </Modal>

    </div>
  );
}
