import { useEffect, useMemo, useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { Tab } from '../types';
import { useGym } from '../store';
import {
  allPRs,
  countSets,
  fmtDateShort,
  fmtDur,
  fmtInt,
  fmtNum,
  muscleBalance,
  prLabel,
  sessionVolume,
  sessionsThisWeek,
  streakWeeks,
  weeklyVolume,
  cap,
} from '../lib/stats';
import { GROUP_COLORS } from '../data/exercises';
import { EmptyState, Reveal, Ring } from '../components/ui';
import { IBolt, IFlame, IMinus, IPlay, IPlus, ITrend, ITrophy, IDumbbell } from '../components/icons';

function MiniTip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="card px-3 py-2 text-xs shadow-xl shadow-black/40">
      <div className="lbl mb-0.5">{label}</div>
      <div className="font-bold text-ember">{fmtInt(payload[0].value)} kg</div>
    </div>
  );
}

export function Dashboard({ go }: { go: (t: Tab) => void }) {
  const { sessions, active, settings, setSettings, exMap, startSession, repeatSession, loadSample } = useGym();
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const week = useMemo(() => sessionsThisWeek(sessions), [sessions]);
  const weeks = useMemo(() => weeklyVolume(sessions, exMap, 8), [sessions, exMap]);
  const thisWeek = weeks[weeks.length - 1];
  const prevWeek = weeks[weeks.length - 2];
  const weekVol = week.reduce((a, s) => a + sessionVolume(s), 0);
  const weekTime = week.reduce((a, s) => a + (s.endTime - s.startTime), 0);
  const weekSets = week.reduce((a, s) => a + countSets(s), 0);
  const streak = useMemo(() => streakWeeks(sessions), [sessions]);
  const prs = useMemo(() => allPRs(sessions).slice(0, 5), [sessions]);
  const balance = useMemo(() => muscleBalance(sessions, exMap), [sessions, exMap]);
  const volTrend = useMemo(
    () =>
      [...sessions]
        .sort((a, b) => a.startTime - b.startTime)
        .slice(-10)
        .map((s) => ({ label: fmtDateShort(s.date), vol: Math.round(sessionVolume(s)) })),
    [sessions],
  );

  const delta =
    prevWeek && prevWeek.total > 0 ? Math.round(((thisWeek.total - prevWeek.total) / prevWeek.total) * 100) : null;
  const maxKg = balance.length ? balance[0].kg : 1;

  const today = new Date(now);
  const weekday = today.toLocaleDateString('es-ES', { weekday: 'long' });
  const month = today.toLocaleDateString('es-ES', { month: 'long' });

  const hasData = sessions.length > 0;

  return (
    <div className="space-y-6">
      {/* cabecera: la fecha manda, como en un diario */}
      <header className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <p className="lbl mb-1.5">Hoy · tu diario de fuerza</p>
          <h1 className="display text-[52px] md:text-7xl leading-[0.9]">
            {weekday} <span className="text-ember">{today.getDate()}</span> {month}
          </h1>
          <p className="text-mut font-semibold mt-2 text-sm">
            {active
              ? 'Tienes una sesión en curso. El hierro no espera.'
              : hasData
                ? `${sessions.length} sesiones registradas. Cada una cuenta.`
                : 'Tu primera página está en blanco. Rómpela.'}
          </p>
        </div>
        {active ? (
          <button onClick={() => go('entrenar')} className="btn btn-mint px-6 py-3.5 text-base">
            <IPlay width={19} height={19} /> Reanudar sesión · {fmtDur(now - active.startedAt)}
          </button>
        ) : (
          <button
            onClick={() => {
              const sorted = [...sessions].sort((a, b) => b.startTime - a.startTime);
              if (hasData && sorted[0]) repeatSession(sorted[0].id);
              else startSession();
              go('entrenar');
            }}
            className="btn btn-ember px-6 py-3.5 text-base"
          >
            <IFlame width={19} height={19} /> {hasData ? 'Repetir último entreno' : 'Empezar a entrenar'}
          </button>
        )}
      </header>

      {!hasData && !active && (
        <EmptyState
          icon={<IDumbbell width={28} height={28} />}
          title="Aún no hay entrenamientos"
          text="Registra tu primera sesión con ejercicios, series, repeticiones, pesos y descansos… o carga 10 semanas de ejemplo para ver cómo funciona todo."
        >
          <button onClick={() => { startSession(); go('entrenar'); }} className="btn btn-ember px-5 py-2.5">
            <IFlame width={17} height={17} /> Crear mi primera sesión
          </button>
          <button onClick={loadSample} className="btn btn-ghost px-5 py-2.5">
            <ITrend width={17} height={17} /> Cargar datos de ejemplo
          </button>
        </EmptyState>
      )}

      {hasData && (
        <>
          {/* fila de indicadores */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <Reveal>
              <div className="card p-4 h-full flex items-center gap-4">
                <Ring pct={week.length / settings.weeklyGoal} size={78} stroke={7}>
                  <span className="display text-2xl leading-none">
                    {week.length}<span className="text-mut2 text-lg">/{settings.weeklyGoal}</span>
                  </span>
                </Ring>
                <div className="min-w-0">
                  <div className="lbl">Esta semana</div>
                  <div className="font-bold text-sm leading-tight mt-1">
                    {week.length} {week.length === 1 ? 'sesión' : 'sesiones'}
                  </div>
                  <div className="flex items-center gap-1 mt-2">
                    <button
                      onClick={() => setSettings({ weeklyGoal: Math.max(1, settings.weeklyGoal - 1) })}
                      className="w-6 h-6 rounded-md bg-raise text-mut hover:text-ink flex items-center justify-center cursor-pointer transition-colors"
                      aria-label="Bajar objetivo"
                    >
                      <IMinus width={13} height={13} />
                    </button>
                    <button
                      onClick={() => setSettings({ weeklyGoal: Math.min(7, settings.weeklyGoal + 1) })}
                      className="w-6 h-6 rounded-md bg-raise text-mut hover:text-ink flex items-center justify-center cursor-pointer transition-colors"
                      aria-label="Subir objetivo"
                    >
                      <IPlus width={13} height={13} />
                    </button>
                    <span className="text-[10px] font-bold text-mut2 uppercase tracking-wider ml-1">Objetivo</span>
                  </div>
                </div>
              </div>
            </Reveal>

            <Reveal delay={60}>
              <div className="card p-4 h-full">
                <div className="flex items-center justify-between">
                  <span className="lbl">Volumen semanal</span>
                  {delta !== null && (
                    <span className={`chip ${delta >= 0 ? 'text-mint bg-mint/10' : 'text-danger bg-danger/10'}`}>
                      {delta >= 0 ? '▲' : '▼'} {Math.abs(delta)}%
                    </span>
                  )}
                </div>
                <div className="display text-[38px] leading-none mt-2.5 tabular-nums">{fmtInt(weekVol)}</div>
                <div className="text-[11px] font-bold text-mut2 uppercase tracking-wider mt-1">kg acumulados</div>
              </div>
            </Reveal>

            <Reveal delay={120}>
              <div className="card p-4 h-full">
                <span className="lbl">Tiempo y series</span>
                <div className="display text-[38px] leading-none mt-2.5 tabular-nums">{weekTime ? fmtDur(weekTime) : '—'}</div>
                <div className="text-[11px] font-bold text-mut2 uppercase tracking-wider mt-1">{weekSets} series completadas</div>
              </div>
            </Reveal>

            <Reveal delay={180}>
              <div className="card p-4 h-full">
                <div className="flex items-center justify-between">
                  <span className="lbl">Racha</span>
                  <IFlame width={17} height={17} className={streak > 0 ? 'text-ember' : 'text-mut2'} />
                </div>
                <div className="display text-[38px] leading-none mt-2.5 tabular-nums">
                  {streak} <span className="text-xl text-mut">sem.</span>
                </div>
                <div className="text-[11px] font-bold text-mut2 uppercase tracking-wider mt-1">
                  {streak > 0 ? 'seguidas entrenando' : 'entrena para abrir racha'}
                </div>
              </div>
            </Reveal>
          </div>

          <div className="grid lg:grid-cols-5 gap-3.5">
            {/* curva de volumen */}
            <Reveal className="lg:col-span-3">
              <div className="card p-5 h-full">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="display text-2xl tracking-wide">Volumen por sesión</h2>
                  <button onClick={() => go('progreso')} className="text-[11px] font-bold uppercase tracking-wider text-ember hover:text-ember2 cursor-pointer">
                    Ver progreso →
                  </button>
                </div>
                {volTrend.length >= 2 ? (
                  <ResponsiveContainer width="100%" height={170}>
                    <AreaChart data={volTrend} margin={{ top: 6, right: 6, left: 6, bottom: 0 }}>
                      <defs>
                        <linearGradient id="gvol" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#ff6b2c" stopOpacity={0.4} />
                          <stop offset="100%" stopColor="#ff6b2c" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke="#222b24" vertical={false} />
                      <XAxis dataKey="label" tick={{ fill: '#64736a', fontSize: 10 }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                      <YAxis hide domain={[0, 'dataMax + 500']} />
                      <Tooltip content={<MiniTip />} cursor={{ stroke: '#3c4a40' }} />
                      <Area type="monotone" dataKey="vol" stroke="#ff6b2c" strokeWidth={2.2} fill="url(#gvol)" />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-sm text-mut py-10 text-center">Registra al menos dos sesiones para ver la curva.</p>
                )}
              </div>
            </Reveal>

            {/* balance muscular */}
            <Reveal delay={80} className="lg:col-span-2">
              <div className="card p-5 h-full">
                <h2 className="display text-2xl tracking-wide mb-4">Balance muscular · semana</h2>
                {balance.length ? (
                  <div className="space-y-3">
                    {balance.map((b) => (
                      <div key={b.group}>
                        <div className="flex items-center justify-between text-xs font-bold mb-1">
                          <span style={{ color: GROUP_COLORS[b.group] }}>{b.group}</span>
                          <span className="text-mut tabular-nums">{fmtInt(b.kg)} kg</span>
                        </div>
                        <div className="h-2 rounded-full bg-panel2 overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-700"
                            style={{ width: `${Math.max(6, (b.kg / maxKg) * 100)}%`, background: GROUP_COLORS[b.group] }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-mut py-8 text-center">Todavía no hay volumen esta semana.</p>
                )}
              </div>
            </Reveal>
          </div>

          {/* últimos récords */}
          {prs.length > 0 && (
            <Reveal>
              <div className="card p-5">
                <div className="flex items-center gap-2 mb-4">
                  <ITrophy width={19} height={19} className="text-gold" />
                  <h2 className="display text-2xl tracking-wide">Últimos récords personales</h2>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {prs.map((pr, i) => (
                    <div key={pr.sessionId + pr.exerciseId + pr.kind + i} className="rounded-lg border border-gold/20 bg-gold/5 px-3.5 py-3">
                      <div className="font-bold text-sm">{pr.exerciseName}</div>
                      <div className="text-xs text-gold font-bold mt-0.5">{prLabel(pr)}</div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-mut2 mt-1">
                        {fmtDateShort(pr.date)}
                        {pr.prev !== undefined && ` · antes ${fmtNum(pr.prev)}${pr.kind === 'reps' ? ' reps' : ' kg'}`}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          )}

          {/* última sesión */}
          {sessions[0] && (
            <Reveal>
              <button
                onClick={() => go('historial')}
                className="card w-full p-5 flex flex-wrap items-center gap-x-6 gap-y-2 text-left hover:border-line2 transition-colors cursor-pointer group"
              >
                <IBolt width={20} height={20} className="text-ember shrink-0" />
                <div>
                  <div className="lbl">Última sesión</div>
                  <div className="font-bold text-sm mt-0.5">
                    {cap(fmtDateShort(sessions[0].date))} · {sessions[0].exercises.length} ejercicios ·{' '}
                    <span className="text-ember">{fmtInt(sessionVolume(sessions[0]))} kg</span> ·{' '}
                    {fmtDur(sessions[0].endTime - sessions[0].startTime)}
                  </div>
                </div>
                <span className="ml-auto text-[11px] font-bold uppercase tracking-wider text-mut2 group-hover:text-ember transition-colors">
                  Abrir historial →
                </span>
              </button>
            </Reveal>
          )}
        </>
      )}
    </div>
  );
}
