import { useMemo, useState } from 'react';
import type { Tab, WorkoutSession } from '../types';
import { useGym } from '../store';
import {
  avgRestOf,
  bestWeightedSet,
  countSets,
  exVolume,
  fmtClock,
  fmtDateShort,
  fmtDur,
  fmtInt,
  fmtMonthYear,
  fmtNum,
  intensityOf,
  maxRepsOf,
  sessionVolume,
  setLabel,
  weekdayShort,
  daysSinceLabel,
} from '../lib/stats';
import { EmptyState, Modal, Reveal } from '../components/ui';
import {
  IBolt,
  IChevD,
  IClock,
  ICompare,
  IDumbbell,
  INote,
  IRepeat,
  ITrash,
  ITrophy,
} from '../components/icons';

function bestSetSummary(s: WorkoutSession, exId: string): { best: string; vol: number; sets: number } {
  const e = s.exercises.find((x) => x.exerciseId === exId);
  if (!e) return { best: '—', vol: 0, sets: 0 };
  if (e.bodyweight) return { best: `PC × ${maxRepsOf(e)}`, vol: exVolume(e), sets: e.sets.length };
  const b = bestWeightedSet(e);
  return { best: b ? setLabel(b) : '—', vol: exVolume(e), sets: e.sets.length };
}

function CompareModal({ a, b, onClose }: { a: WorkoutSession; b: WorkoutSession; onClose: () => void }) {
  const { exMap } = useGym();
  const [older, newer] = a.startTime <= b.startTime ? [a, b] : [b, a];
  const ids = useMemo(() => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const s of [newer, older])
      for (const e of s.exercises)
        if (!seen.has(e.exerciseId)) {
          seen.add(e.exerciseId);
          out.push(e.exerciseId);
        }
    return out;
  }, [newer, older]);

  const volA = sessionVolume(older);
  const volB = sessionVolume(newer);
  const dVol = volA > 0 ? Math.round(((volB - volA) / volA) * 100) : 0;

  return (
    <Modal open onClose={onClose} title="Comparar sesiones" wide>
      <div className="grid grid-cols-[1fr_92px_92px_74px] sm:grid-cols-[1fr_120px_120px_84px] gap-y-1 items-center text-sm">
        <span className="lbl">Ejercicio</span>
        <span className="lbl text-center">{fmtDateShort(older.date)}</span>
        <span className="lbl text-center text-ember">{fmtDateShort(newer.date)}</span>
        <span className="lbl text-right">Δ vol.</span>

        {ids.map((id) => {
          const A = bestSetSummary(older, id);
          const B = bestSetSummary(newer, id);
          const d = A.vol > 0 ? Math.round(((B.vol - A.vol) / A.vol) * 100) : B.vol > 0 ? 100 : 0;
          return (
            <div key={id} className="contents">
              <div className="font-bold py-2 pr-2 border-t border-line truncate">
                {exMap[id]?.name ?? id}
                <div className="text-[10px] font-bold uppercase tracking-wider text-mut2">{B.sets || A.sets} series</div>
              </div>
              <div className="py-2 text-center border-t border-line">
                <div className="font-bold tabular-nums text-mut">{A.best}</div>
                <div className="text-[10px] text-mut2 tabular-nums">{fmtInt(A.vol)} kg</div>
              </div>
              <div className="py-2 text-center border-t border-line">
                <div className="font-bold tabular-nums text-ink">{B.best}</div>
                <div className="text-[10px] text-mut2 tabular-nums">{fmtInt(B.vol)} kg</div>
              </div>
              <div className={`py-2 text-right border-t border-line font-bold tabular-nums text-xs ${d > 0 ? 'text-mint' : d < 0 ? 'text-danger' : 'text-mut2'}`}>
                {d > 0 ? `▲ ${d}%` : d < 0 ? `▼ ${Math.abs(d)}%` : '—'}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 rounded-lg bg-panel2 border border-line p-3.5 flex flex-wrap gap-x-6 gap-y-1.5 text-xs font-bold">
        <span className="text-mut2 uppercase tracking-wider">Totales</span>
        <span>Volumen: {fmtInt(volA)} → <span className="text-ember">{fmtInt(volB)} kg</span> <span className={dVol >= 0 ? 'text-mint' : 'text-danger'}>({dVol >= 0 ? `▲${dVol}` : `▼${Math.abs(dVol)}`}%)</span></span>
        <span>Series: {countSets(older)} → <span className="text-ink">{countSets(newer)}</span></span>
        <span>Duración: {fmtDur(older.endTime - older.startTime)} → <span className="text-ink">{fmtDur(newer.endTime - newer.startTime)}</span></span>
      </div>
    </Modal>
  );
}

export function History({ go }: { go: (t: Tab) => void }) {
  const { sessions, exMap, deleteSession, repeatSession, toast } = useGym();
  const [expanded, setExpanded] = useState<string | null>(null);
  const [compare, setCompare] = useState<string[]>([]);
  const [askDelete, setAskDelete] = useState<string | null>(null);

  const sorted = useMemo(() => [...sessions].sort((a, b) => b.startTime - a.startTime), [sessions]);
  const groups = useMemo(() => {
    const m = new Map<string, WorkoutSession[]>();
    for (const s of sorted) {
      const k = fmtMonthYear(s.date);
      m.set(k, [...(m.get(k) ?? []), s]);
    }
    return [...m.entries()];
  }, [sorted]);

  const toggleCompare = (id: string) =>
    setCompare((c) => {
      if (c.includes(id)) return c.filter((x) => x !== id);
      if (c.length >= 2) return [c[1], id];
      return [...c, id];
    });

  const sel = compare.map((id) => sessions.find((s) => s.id === id)).filter(Boolean) as WorkoutSession[];

  if (!sessions.length)
    return (
      <EmptyState
        icon={<IClock width={28} height={28} />}
        title="Historial vacío"
        text="Cuando guardes tu primera sesión aparecerá aquí, con todo lo que hiciste: ejercicios, series, pesos y descansos."
      >
        <button onClick={() => go('entrenar')} className="btn btn-ember px-5 py-2.5">
          <IDumbbell width={17} height={17} /> Ir a entrenar
        </button>
      </EmptyState>
    );

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="lbl mb-1">Diario completo</p>
          <h1 className="display text-5xl md:text-6xl leading-none">Historial</h1>
        </div>
        <p className="text-xs font-bold text-mut2 uppercase tracking-wider">
          {compare.length === 0 && 'Marca 2 sesiones para compararlas'}
          {compare.length === 1 && 'Una seleccionada · elige otra'}
        </p>
      </header>

      {groups.map(([month, list]) => (
        <section key={month}>
          <h2 className="display text-2xl text-mut tracking-wide mb-2.5 flex items-center gap-3">
            {month}
            <span className="h-px flex-1 bg-line" />
          </h2>
          <div className="space-y-2.5">
            {list.map((s, idx) => {
              const vol = sessionVolume(s);
              const durMin = (s.endTime - s.startTime) / 60000;
              const inten = intensityOf(vol, durMin);
              const isOpen = expanded === s.id;
              const inCompare = compare.includes(s.id);
              const day = new Date(s.date + 'T12:00:00').getDate();
              return (
                <Reveal key={s.id} delay={Math.min(idx * 50, 200)}>
                  <div className={`card transition-colors ${inCompare ? 'border-ember/60' : ''} ${isOpen ? 'bg-panel2' : ''}`}>
                    <div className="flex items-center gap-3.5 px-4 py-3.5">
                      <div className="text-center shrink-0 w-12">
                        <div className="display text-4xl leading-none text-ember tabular-nums">{day}</div>
                        <div className="text-[10px] font-bold uppercase tracking-wider text-mut2">{weekdayShort(s.date)}</div>
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className={`chip ${inten.cls}`}>{inten.label}</span>
                          {s.prs.length > 0 && (
                            <span className="chip text-gold bg-gold/12">
                              <ITrophy width={12} height={12} /> {s.prs.length} RP
                            </span>
                          )}
                          {s.energy && (
                            <span className="chip text-gold/80 bg-gold/8">
                              <IBolt width={11} height={11} fill="currentColor" /> {s.energy}/5
                            </span>
                          )}
                        </div>
                        <div className="text-xs font-bold text-mut mt-1.5 tabular-nums">
                          {s.exercises.length} ejercicios · <span className="text-ink">{fmtInt(vol)} kg</span> ·{' '}
                          {fmtDur(s.endTime - s.startTime)} · {countSets(s)} series
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => { repeatSession(s.id); go('entrenar'); }}
                          title="Repetir esta sesión"
                          className="w-8 h-8 rounded-lg text-mut hover:text-mint hover:bg-mint/10 flex items-center justify-center transition-colors cursor-pointer"
                        >
                          <IRepeat width={16} height={16} />
                        </button>
                        <button
                          onClick={() => setAskDelete(s.id)}
                          title="Eliminar sesión"
                          className="w-8 h-8 rounded-lg text-mut hover:text-danger hover:bg-danger/10 flex items-center justify-center transition-colors cursor-pointer"
                        >
                          <ITrash width={16} height={16} />
                        </button>
                        <button
                          onClick={() => toggleCompare(s.id)}
                          title="Seleccionar para comparar"
                          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                            inCompare ? 'text-ember bg-ember/12' : 'text-mut hover:text-ember hover:bg-ember/10'
                          }`}
                        >
                          <ICompare width={16} height={16} />
                        </button>
                        <button
                          onClick={() => setExpanded(isOpen ? null : s.id)}
                          className="w-8 h-8 rounded-lg text-mut hover:text-ink hover:bg-raise flex items-center justify-center transition-all cursor-pointer"
                          aria-label="Ver detalle"
                        >
                          <IChevD width={17} height={17} className={`transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                        </button>
                      </div>
                    </div>

                    {isOpen && (
                      <div className="px-4 pb-4 anim-fade-up">
                        <div className="rounded-lg border border-line bg-panel overflow-hidden">
                          {s.exercises.map((e, i) => {
                            const def = exMap[e.exerciseId];
                            const avgR = e.sets.filter((x) => x.restAfter).map((x) => x.restAfter as number);
                            return (
                              <div key={e.id} className={`px-3.5 py-2.5 ${i ? 'border-t border-line' : ''}`}>
                                <div className="flex items-center justify-between gap-3">
                                  <span className="font-bold text-sm">{def?.name ?? e.exerciseId}</span>
                                  <span className="text-[11px] font-bold text-mut2 tabular-nums shrink-0">
                                    {fmtInt(exVolume(e))} kg
                                    {avgR.length > 0 && <> · desc. {fmtClock(avgR.reduce((a, b) => a + b, 0) / avgR.length)}</>}
                                  </span>
                                </div>
                                <div className="text-xs text-mut font-semibold mt-0.5 flex flex-wrap gap-x-2">
                                  {e.sets.map((st, j) => (
                                    <span key={st.id} className="tabular-nums">
                                      <span className="text-mut2">{j + 1}.</span> {setLabel(st)}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                        {(s.notes || avgRestOf(s) !== null) && (
                          <div className="flex flex-wrap gap-x-5 gap-y-1.5 mt-3 text-xs font-bold text-mut2">
                            {avgRestOf(s) !== null && (
                              <span className="flex items-center gap-1.5 uppercase tracking-wider">
                                <IClock width={13} height={13} /> Descanso medio: <span className="text-mut">{fmtClock(avgRestOf(s) as number)}</span>
                              </span>
                            )}
                            {s.notes && (
                              <span className="flex items-start gap-1.5 normal-case tracking-normal text-mut font-semibold">
                                <INote width={13} height={13} className="mt-0.5 shrink-0 text-mut2" /> {s.notes}
                              </span>
                            )}
                          </div>
                        )}
                        {s.prs.length > 0 && (
                          <div className="mt-3 flex flex-wrap gap-1.5">
                            {s.prs.map((pr, i) => (
                              <span key={i} className="chip text-gold bg-gold/10 border border-gold/25">
                                <ITrophy width={12} height={12} /> {pr.exerciseName} ·{' '}
                                {pr.kind === 'reps' ? `${pr.value} reps` : `${fmtNum(pr.value)} kg`}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </Reveal>
              );
            })}
          </div>
        </section>
      ))}

      <div className="h-8" />

      {compare.length === 2 && sel.length === 2 && (
        <div className="anim-slide-up fixed left-1/2 bottom-[76px] md:bottom-6 z-40 flex items-center gap-3">
          <button onClick={() => setCompare([])} className="btn btn-ghost px-4 py-3 shadow-xl shadow-black/50">
            Cancelar
          </button>
          <CompareTrigger a={sel[0]} b={sel[1]} />
        </div>
      )}

      <Modal open={!!askDelete} onClose={() => setAskDelete(null)} title="¿Eliminar sesión?">
        <p className="text-sm text-mut mb-5">
          Esta sesión del {askDelete ? daysSinceLabel(sorted.find((s) => s.id === askDelete)?.date ?? '') : ''} se borrará
          del diario para siempre.
        </p>
        <div className="flex gap-2.5">
          <button onClick={() => setAskDelete(null)} className="btn btn-ghost px-4 py-2.5 flex-1">Conservar</button>
          <button
            onClick={() => {
              if (askDelete) deleteSession(askDelete);
              setCompare((c) => c.filter((x) => x !== askDelete));
              setAskDelete(null);
              toast('Sesión eliminada.', 'warn');
            }}
            className="btn btn-danger px-4 py-2.5 flex-1"
          >
            <ITrash width={16} height={16} /> Eliminar
          </button>
        </div>
      </Modal>
    </div>
  );
}

function CompareTrigger({ a, b }: { a: WorkoutSession; b: WorkoutSession }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)} className="btn btn-ember px-5 py-3 shadow-xl shadow-black/50">
        <ICompare width={17} height={17} /> Comparar sesiones
      </button>
      {open && <CompareModal a={a} b={b} onClose={() => setOpen(false)} />}
    </>
  );
}
