import { useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { MuscleGroup, Tab } from '../types';
import { useGym } from '../store';
import { GROUPS, GROUP_COLORS } from '../data/exercises';
import {
  allPRs,
  exerciseSeries,
  fmtDateShort,
  fmtInt,
  fmtNum,
  prLabel,
  weeklyVolume,
} from '../lib/stats';
import { EmptyState, Modal, GroupChip, Reveal, Seg } from '../components/ui';
import { IChevD, ISearch, ITrend, ITrophy } from '../components/icons';

type Metric = 'maxW' | 'e1' | 'vol' | 'reps';

const METRICS: { v: Metric; label: string; unit: string; color: string }[] = [
  { v: 'maxW', label: 'Peso máx', unit: 'kg', color: '#ff6b2c' },
  { v: 'e1', label: '1RM est.', unit: 'kg', color: '#ffc65c' },
  { v: 'vol', label: 'Volumen', unit: 'kg', color: '#3ddc97' },
  { v: 'reps', label: 'Repeticiones', unit: 'reps', color: '#6fc7de' },
];

function ChartTip({ active, payload, label, unit }: { active?: boolean; payload?: { value: number }[]; label?: string; unit: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="card px-3 py-2 text-xs shadow-xl shadow-black/40">
      <div className="lbl mb-0.5">{label}</div>
      <div className="font-bold tabular-nums" style={{ color: 'var(--color-ink)' }}>
        {fmtNum(payload[0].value)} {unit}
      </div>
    </div>
  );
}

function StackedTip({ active, payload, label }: { active?: boolean; payload?: { name: string; value: number; color: string }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  const total = payload.reduce((a, p) => a + (p.value ?? 0), 0);
  return (
    <div className="card px-3 py-2 text-xs shadow-xl shadow-black/40 min-w-[130px]">
      <div className="lbl mb-1.5">Semana del {label}</div>
      {payload.filter((p) => p.value > 0).map((p) => (
        <div key={p.name} className="flex items-center gap-2 py-0.5">
          <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: p.color }} />
          <span className="text-mut font-semibold flex-1">{p.name}</span>
          <span className="font-bold tabular-nums">{fmtInt(p.value)}</span>
        </div>
      ))}
      <div className="flex justify-between mt-1.5 pt-1.5 border-t border-line font-bold">
        <span className="text-mut2 uppercase tracking-wider text-[10px]">Total</span>
        <span className="tabular-nums text-ember">{fmtInt(total)} kg</span>
      </div>
    </div>
  );
}

export function Progress({ go }: { go: (t: Tab) => void }) {
  const { sessions, exMap } = useGym();
  const [selId, setSelId] = useState<string | null>(null);
  const [metric, setMetric] = useState<Metric>('maxW');
  const [pickerOpen, setPickerOpen] = useState(false);
  const [q, setQ] = useState('');

  const usage = useMemo(() => {
    const m: Record<string, { count: number; last: number }> = {};
    for (const s of sessions)
      for (const e of s.exercises) {
        m[e.exerciseId] = { count: (m[e.exerciseId]?.count ?? 0) + 1, last: s.startTime };
      }
    return m;
  }, [sessions]);

  const available = useMemo(
    () => Object.keys(usage).sort((a, b) => usage[b].last - usage[a].last),
    [usage],
  );

  const selected = selId && usage[selId] ? selId : available[0] ?? null;
  const series = useMemo(
    () => (selected ? exerciseSeries(sessions, selected) : []),
    [sessions, selected],
  );

  const metricDef = METRICS.find((m) => m.v === metric) ?? METRICS[0];
  const values = series.map((p) => p[metric] as number);
  const current = values.length ? values[values.length - 1] : 0;
  const best = values.length ? Math.max(...values) : 0;
  const first = values.length ? values[0] : 0;
  const improvement = first > 0 ? Math.round(((best - first) / first) * 100) : null;

  const weeks = useMemo(() => weeklyVolume(sessions, exMap, 8), [sessions, exMap]);
  const activeGroups = useMemo(() => {
    const set = new Set<MuscleGroup>();
    for (const w of weeks) for (const g of Object.keys(w.groups)) set.add(g as MuscleGroup);
    return GROUPS.filter((g) => set.has(g));
  }, [weeks]);

  const prs = useMemo(() => allPRs(sessions).slice(0, 9), [sessions]);

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return available.filter((id) => !qq || (exMap[id]?.name ?? id).toLowerCase().includes(qq));
  }, [available, q, exMap]);

  if (!sessions.length)
    return (
      <EmptyState
        icon={<ITrend width={28} height={28} />}
        title="Sin datos que graficar"
        text="Cuando registres sesiones podrás ver aquí tu evolución de fuerza, 1RM estimado, volumen y repeticiones ejercicio a ejercicio."
      >
        <button onClick={() => go('entrenar')} className="btn btn-ember px-5 py-2.5">
          <ITrend width={17} height={17} /> Entrenar ahora
        </button>
      </EmptyState>
    );

  return (
    <div className="space-y-6">
      <header>
        <p className="lbl mb-1">Evolución</p>
        <h1 className="display text-5xl md:text-6xl leading-none">Progreso</h1>
      </header>

      {/* selector de ejercicio + métrica */}
      <Reveal>
        <div className="card p-4 flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => setPickerOpen(true)}
            className="btn btn-ghost px-4 py-2.5 flex-1 justify-between normal-case tracking-normal text-sm group"
          >
            <span className="font-bold">{selected ? exMap[selected]?.name ?? selected : 'Elige un ejercicio'}</span>
            <IChevD width={16} height={16} className="text-mut2 group-hover:text-ember transition-colors" />
          </button>
          <Seg options={METRICS.map((m) => ({ v: m.v, label: m.label }))} value={metric} onChange={setMetric} className="sm:w-[380px]" />
        </div>
      </Reveal>

      {selected && (
        <>
          {/* estadísticas del ejercicio */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            {[
              { l: 'Último registro', v: current, extra: series.length ? fmtDateShort(series[series.length - 1].date) : '—' },
              { l: 'Mejor marca', v: best, extra: metricDef.unit },
              { l: 'Mejora vs. inicio', v: improvement, extra: improvement !== null ? '%' : '—', raw: true },
              { l: 'Veces entrenado', v: usage[selected]?.count ?? 0, extra: 'sesiones' },
            ].map((t, i) => (
              <Reveal key={t.l} delay={i * 50}>
                <div className="card p-4">
                  <div className="lbl">{t.l}</div>
                  <div className="display text-[32px] leading-none mt-2 tabular-nums" style={{ color: i === 1 ? metricDef.color : undefined }}>
                    {t.v === null || t.v === undefined ? '—' : fmtNum(t.v)}
                    <span className="text-base text-mut2 ml-1">{t.raw ? '' : ''}</span>
                  </div>
                  <div className="text-[11px] font-bold text-mut2 uppercase tracking-wider mt-1">{t.extra}</div>
                </div>
              </Reveal>
            ))}
          </div>

          {/* gráfica principal */}
          <Reveal>
            <div className="card p-5">
              <div className="flex items-center justify-between mb-2">
                <h2 className="display text-2xl tracking-wide">
                  {metricDef.label} · {exMap[selected]?.name ?? selected}
                </h2>
                <span className="chip" style={{ color: metricDef.color, background: metricDef.color + '1c' }}>
                  {metricDef.unit}
                </span>
              </div>
              {series.length >= 2 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <AreaChart data={series.map((p) => ({ label: p.label, val: p[metric] }))} margin={{ top: 8, right: 8, left: 8, bottom: 0 }}>
                    <defs>
                      <linearGradient id="gmetric" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={metricDef.color} stopOpacity={0.38} />
                        <stop offset="100%" stopColor={metricDef.color} stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid stroke="#222b24" vertical={false} />
                    <XAxis dataKey="label" tick={{ fill: '#64736a', fontSize: 10 }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                    <YAxis
                      tick={{ fill: '#64736a', fontSize: 10 }}
                      axisLine={false}
                      tickLine={false}
                      width={40}
                      domain={['auto', 'auto']}
                    />
                    <Tooltip content={<ChartTip unit={metricDef.unit} />} cursor={{ stroke: '#3c4a40' }} />
                    <Area type="monotone" dataKey="val" stroke={metricDef.color} strokeWidth={2.4} fill="url(#gmetric)" dot={{ r: 3, fill: metricDef.color, strokeWidth: 0 }} />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-sm text-mut py-12 text-center">
                  Solo hay un registro de este ejercicio: entrena otra vez para ver la curva.
                </p>
              )}
            </div>
          </Reveal>
        </>
      )}

      <div className="grid lg:grid-cols-5 gap-3.5">
        {/* volumen semanal apilado */}
        <Reveal className="lg:col-span-3">
          <div className="card p-5 h-full">
            <h2 className="display text-2xl tracking-wide mb-3">Volumen semanal por grupo</h2>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={weeks.map((w) => ({ label: w.label, ...w.groups }))} margin={{ top: 6, right: 4, left: 4, bottom: 0 }} barCategoryGap="28%">
                <CartesianGrid stroke="#222b24" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: '#64736a', fontSize: 10 }} axisLine={false} tickLine={false} interval={1} />
                <YAxis hide />
                <Tooltip content={<StackedTip />} cursor={{ fill: 'rgba(233,237,230,0.04)' }} />
                {activeGroups.map((g) => (
                  <Bar key={g} dataKey={g} stackId="v" fill={GROUP_COLORS[g]} radius={g === activeGroups[activeGroups.length - 1] ? [3, 3, 0, 0] : 0} />
                ))}
              </BarChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-x-4 gap-y-1.5 mt-2">
              {activeGroups.map((g) => (
                <span key={g} className="flex items-center gap-1.5 text-[11px] font-bold text-mut">
                  <span className="w-2.5 h-2.5 rounded-sm" style={{ background: GROUP_COLORS[g] }} /> {g}
                </span>
              ))}
            </div>
          </div>
        </Reveal>

        {/* cronología de récords */}
        <Reveal delay={80} className="lg:col-span-2">
          <div className="card p-5 h-full">
            <div className="flex items-center gap-2 mb-3">
              <ITrophy width={18} height={18} className="text-gold" />
              <h2 className="display text-2xl tracking-wide">Récords recientes</h2>
            </div>
            {prs.length ? (
              <div className="space-y-2.5 max-h-[248px] overflow-y-auto pr-1">
                {prs.map((pr, i) => (
                  <div key={pr.sessionId + i} className="flex items-start gap-2.5">
                    <span className="display text-lg text-gold/70 w-6 text-right shrink-0 tabular-nums">{i + 1}</span>
                    <div className="min-w-0 border-b border-line pb-2 flex-1">
                      <div className="text-sm font-bold truncate">{pr.exerciseName}</div>
                      <div className="text-[11px] font-bold text-gold">{prLabel(pr)}</div>
                      <div className="text-[10px] font-bold text-mut2 uppercase tracking-wider mt-0.5">
                        {fmtDateShort(pr.date)}
                        {pr.prev !== undefined && ` · antes ${fmtNum(pr.prev)}${pr.kind === 'reps' ? ' reps' : ' kg'}`}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-mut py-8 text-center">Aún no hay récords: supera tus marcas para verlos aquí.</p>
            )}
          </div>
        </Reveal>
      </div>

      {/* selector modal */}
      <Modal open={pickerOpen} onClose={() => setPickerOpen(false)} title="Ejercicio">
        <div className="relative mb-3">
          <ISearch width={16} height={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-mut2" />
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar…" className="inp pl-9" />
        </div>
        <div className="max-h-[50vh] overflow-y-auto space-y-1">
          {filtered.map((id) => (
            <button
              key={id}
              onClick={() => { setSelId(id); setPickerOpen(false); }}
              className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors cursor-pointer ${
                id === selected ? 'bg-ember/10' : 'hover:bg-raise/70'
              }`}
            >
              <span className="min-w-0 flex-1">
                <span className="font-bold text-sm block truncate">{exMap[id]?.name ?? id}</span>
                <span className="text-[11px] font-bold text-mut2 uppercase tracking-wider">{usage[id]?.count ?? 0} sesiones</span>
              </span>
              {exMap[id] && <GroupChip group={exMap[id].group} />}
            </button>
          ))}
          {!filtered.length && <p className="text-sm text-mut text-center py-8">Sin resultados.</p>}
        </div>
      </Modal>
    </div>
  );
}
