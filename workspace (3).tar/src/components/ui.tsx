import React, { useEffect, useRef, useState } from 'react';
import type { MuscleGroup } from '../types';
import { GROUP_COLORS } from '../data/exercises';
import { fmtNum } from '../lib/stats';
import { useGym } from '../store';
import { ICheck, IInfo, ITrophy, IX } from './icons';

/* ---------- Modal ---------- */
export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const fn = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', fn);
    return () => window.removeEventListener('keydown', fn);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 sm:p-6 bg-[#070a08]/75 backdrop-blur-[3px]"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className={`card w-full ${wide ? 'max-w-2xl' : 'max-w-md'} max-h-[86vh] flex flex-col anim-pop shadow-2xl shadow-black/50`}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-line shrink-0">
          <h3 className="display text-2xl tracking-wide">{title}</h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-mut hover:text-ink hover:bg-raise transition-colors cursor-pointer"
            aria-label="Cerrar"
          >
            <IX width={18} height={18} />
          </button>
        </div>
        <div className="p-5 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

/* ---------- Stepper numérico ---------- */
export function Stepper({
  value,
  onChange,
  step = 1,
  min = 0,
  max = 9999,
  unit,
  className = '',
}: {
  value: number;
  onChange: (n: number) => void;
  step?: number;
  min?: number;
  max?: number;
  unit?: string;
  className?: string;
}) {
  const [txt, setTxt] = useState<string | null>(null);
  const clamp = (n: number) => Math.min(max, Math.max(min, Math.round(n * 100) / 100));
  const commit = () => {
    if (txt === null) return;
    const n = parseFloat(txt.replace(',', '.'));
    onChange(Number.isNaN(n) ? value : clamp(n));
    setTxt(null);
  };
  const bump = (dir: number) => onChange(clamp(value + dir * step));

  return (
    <div className={`flex items-stretch rounded-lg border border-line bg-panel2 overflow-hidden ${className}`}>
      <button
        type="button"
        tabIndex={-1}
        onClick={() => bump(-1)}
        className="px-2 text-mut hover:text-ink hover:bg-raise transition-colors cursor-pointer active:bg-line"
        aria-label="Restar"
      >
        −
      </button>
      <div className="relative flex-1 min-w-0">
        <input
          value={txt !== null ? txt : fmtNum(value)}
          onChange={(e) => setTxt(e.target.value)}
          onBlur={commit}
          onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
          inputMode="decimal"
          className="w-full bg-transparent text-center text-sm font-bold py-1.5 outline-none text-ink"
        />
        {unit && (
          <span className="absolute right-1.5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-mut2 pointer-events-none">
            {unit}
          </span>
        )}
      </div>
      <button
        type="button"
        tabIndex={-1}
        onClick={() => bump(1)}
        className="px-2 text-mut hover:text-ink hover:bg-raise transition-colors cursor-pointer active:bg-line"
        aria-label="Sumar"
      >
        +
      </button>
    </div>
  );
}

/* ---------- Control segmentado ---------- */
export function Seg<T extends string>({
  options,
  value,
  onChange,
  className = '',
}: {
  options: { v: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={`flex rounded-lg border border-line bg-panel2 p-1 gap-1 ${className}`}>
      {options.map((o) => (
        <button
          key={o.v}
          onClick={() => onChange(o.v)}
          className={`flex-1 min-w-0 truncate px-1.5 sm:px-3 py-1.5 rounded-md text-[11px] sm:text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
            value === o.v ? 'bg-ember/15 text-ember shadow-[inset_0_0_0_1px_rgba(255,107,44,0.35)]' : 'text-mut hover:text-ink'
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/* ---------- Chip de grupo muscular ---------- */
export function GroupChip({ group }: { group: MuscleGroup }) {
  const c = GROUP_COLORS[group];
  return (
    <span className="chip" style={{ color: c, background: c + '1c' }}>
      {group}
    </span>
  );
}

/* ---------- Anillo de progreso ---------- */
export function Ring({
  pct,
  size = 88,
  stroke = 8,
  color = '#ff6b2c',
  children,
}: {
  pct: number;
  size?: number;
  stroke?: number;
  color?: string;
  children?: React.ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#29332c" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - Math.min(1, Math.max(0, pct)))}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          style={{ transition: 'stroke-dashoffset 0.9s cubic-bezier(0.2,0.7,0.3,1)' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

/* ---------- Revelado al hacer scroll ---------- */
export function Reveal({
  children,
  delay = 0,
  className = '',
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setOn(true);
          io.disconnect();
        }
      },
      { threshold: 0.1 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal ${on ? 'on' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ---------- Toasts ---------- */
export function ToastHost() {
  const { toasts, dismissToast } = useGym();
  return (
    <div className="fixed top-4 right-4 z-[70] flex flex-col gap-2 w-[min(92vw,340px)]">
      {toasts.map((t) => {
        const style =
          t.kind === 'pr'
            ? 'border-gold/50 text-gold pr-shine'
            : t.kind === 'warn'
              ? 'border-danger/50 text-danger'
              : t.kind === 'info'
                ? 'border-steel/50 text-steel'
                : 'border-mint/50 text-mint';
        return (
          <button
            key={t.id}
            onClick={() => dismissToast(t.id)}
            className={`anim-toast card ${style} flex items-start gap-2.5 px-4 py-3 text-left text-sm font-semibold text-ink border cursor-pointer hover:brightness-110`}
          >
            <span className={`mt-0.5 shrink-0 ${t.kind === 'pr' ? 'text-gold' : t.kind === 'warn' ? 'text-danger' : t.kind === 'info' ? 'text-steel' : 'text-mint'}`}>
              {t.kind === 'pr' ? <ITrophy width={17} height={17} /> : t.kind === 'warn' || t.kind === 'info' ? <IInfo width={17} height={17} /> : <ICheck width={17} height={17} />}
            </span>
            <span>{t.text}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------- Estado vacío ---------- */
export function EmptyState({
  icon,
  title,
  text,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  text: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="card px-6 py-12 text-center flex flex-col items-center anim-fade-up">
      <div className="w-14 h-14 rounded-xl bg-ember/10 text-ember flex items-center justify-center mb-4">{icon}</div>
      <h3 className="display text-3xl mb-1">{title}</h3>
      <p className="text-mut text-sm max-w-sm mb-6">{text}</p>
      <div className="flex flex-wrap gap-3 justify-center">{children}</div>
    </div>
  );
}
