import { useEffect, useRef, useState } from 'react';
import { useGym } from '../store';
import { fmtClock } from '../lib/stats';
import { ITimer, IX } from './icons';

function beep() {
  try {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    [0, 0.2, 0.4].forEach((t) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = 880;
      o.connect(g);
      g.connect(ctx.destination);
      const at = ctx.currentTime + t;
      g.gain.setValueAtTime(0.0001, at);
      g.gain.exponentialRampToValueAtTime(0.22, at + 0.025);
      g.gain.exponentialRampToValueAtTime(0.0001, at + 0.17);
      o.start(at);
      o.stop(at + 0.2);
    });
  } catch {
    /* audio no disponible */
  }
}

const PRESETS = [30, 60, 90, 120, 180];

export function RestTimer() {
  const { rest, stopRest, bumpRest, startRest, toast } = useGym();
  const [remaining, setRemaining] = useState(0);
  const firedRef = useRef(false);

  useEffect(() => {
    if (!rest) return;
    firedRef.current = false;
    const tick = () => {
      const rem = (rest.endsAt - Date.now()) / 1000;
      setRemaining(rem);
      if (rem <= 0 && !firedRef.current) {
        firedRef.current = true;
        beep();
        if ('vibrate' in navigator) navigator.vibrate?.([180, 80, 180]);
        toast('Descanso terminado · ¡a por la siguiente serie!', 'info');
        stopRest();
      }
    };
    tick();
    const id = window.setInterval(tick, 200);
    return () => window.clearInterval(id);
  }, [rest, stopRest, toast]);

  if (!rest) return null;

  const total = Math.max(1, rest.total);
  const shown = Math.max(0, remaining);
  const frac = Math.min(1, Math.max(0, shown / total));
  const size = 64;
  const stroke = 6;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const done = shown <= 0;

  return (
    <div
      className="anim-slide-up fixed left-1/2 bottom-[76px] md:bottom-6 z-50 card border-line2 bg-panel/95 backdrop-blur px-4 py-3 flex items-center gap-4 shadow-2xl shadow-black/60"
      style={{ maxWidth: 'min(94vw, 480px)' }}
    >
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size}>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#29332c" strokeWidth={stroke} />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke={done ? '#3ddc97' : '#ff6b2c'}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={c}
            strokeDashoffset={c * (1 - frac)}
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <ITimer width={20} height={20} className={done ? 'text-mint' : 'text-ember'} />
        </div>
      </div>

      <div className="min-w-0">
        <div className="lbl">Descanso</div>
        <div className={`display text-4xl leading-none tabular-nums ${done ? 'text-mint' : ''}`}>{fmtClock(shown)}</div>
        {rest.label && <div className="text-[11px] text-mut font-semibold truncate max-w-[170px]">{rest.label}</div>}
      </div>

      <div className="flex flex-col gap-1.5 ml-1">
        <div className="flex gap-1">
          <button
            onClick={() => bumpRest(-15)}
            className="btn btn-ghost px-2 py-1 text-[11px] font-bold"
            aria-label="Quince segundos menos"
          >
            −15s
          </button>
          <button
            onClick={() => bumpRest(15)}
            className="btn btn-ghost px-2 py-1 text-[11px] font-bold"
            aria-label="Quince segundos más"
          >
            +15s
          </button>
        </div>
        <div className="flex gap-1 flex-wrap max-w-[180px]">
          {PRESETS.map((p) => (
            <button
              key={p}
              onClick={() => startRest(p, rest.label)}
              className={`px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                rest.total === p ? 'bg-ember/20 text-ember' : 'bg-raise text-mut hover:text-ink'
              }`}
            >
              {p >= 60 ? `${p / 60}m${p % 60 ? `:${(p % 60).toString().padStart(2, '0')}` : ''}` : `${p}s`}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={stopRest}
        className="p-1.5 rounded-lg text-mut hover:text-danger hover:bg-raise transition-colors cursor-pointer self-start"
        aria-label="Detener descanso"
      >
        <IX width={17} height={17} />
      </button>
    </div>
  );
}
