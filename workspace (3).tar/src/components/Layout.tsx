import React, { useRef, useState } from 'react';
import type { Tab } from '../types';
import { useGym } from '../store';
import { fmtClock } from '../lib/stats';
import { Modal, Stepper, ToastHost } from './ui';
import {
  IClock,
  IDownload,
  IFlame,
  IGear,
  IHome,
  IList,
  ITrash,
  ITrend,
  IUpload,
  Logo,
} from './icons';

const NAV: { id: Tab; label: string; icon: (p: React.SVGProps<SVGSVGElement>) => React.ReactElement }[] = [
  { id: 'inicio', label: 'Inicio', icon: IHome },
  { id: 'entrenar', label: 'Entrenar', icon: IFlame },
  { id: 'historial', label: 'Historial', icon: IClock },
  { id: 'progreso', label: 'Progreso', icon: ITrend },
  { id: 'ejercicios', label: 'Ejercicios', icon: IList },
];

export function Layout({
  tab,
  setTab,
  children,
}: {
  tab: Tab;
  setTab: (t: Tab) => void;
  children: React.ReactNode;
}) {
  const { active, settings, setSettings, exportData, importData, loadSample, clearAll, sessions, toast } = useGym();
  const [openSettings, setOpenSettings] = useState(false);
  const [confirmWipe, setConfirmWipe] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="min-h-screen">
      {/* fondo ambiental */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-blueprint" />
        <div className="glow-a absolute -top-[20vw] -right-[15vw] w-[65vw] h-[65vw] rounded-full" />
        <div className="glow-b absolute -bottom-[25vw] -left-[18vw] w-[70vw] h-[70vw] rounded-full" />
      </div>

      {/* sidebar escritorio */}
      <aside className="hidden md:flex fixed left-0 top-0 bottom-0 w-[74px] xl:w-[216px] flex-col border-r border-line bg-panel/85 backdrop-blur z-40">
        <button
          onClick={() => setTab('inicio')}
          className="flex items-center gap-3 px-4 xl:px-5 h-[68px] border-b border-line cursor-pointer group"
        >
          <Logo className="w-9 h-9 shrink-0 transition-transform group-hover:rotate-[-6deg]" />
          <span className="hidden xl:block text-left">
            <span className="display text-[26px] leading-none block tracking-wide">FORJA</span>
            <span className="text-[10px] font-bold uppercase tracking-[0.22em] text-mut2">Diario de fuerza</span>
          </span>
        </button>

        <nav className="flex-1 py-4 flex flex-col gap-1">
          {NAV.map((n) => {
            const Icon = n.icon;
            const isActive = tab === n.id;
            return (
              <button
                key={n.id}
                onClick={() => setTab(n.id)}
                className={`relative mx-2.5 xl:mx-3 h-11 rounded-lg flex items-center justify-center xl:justify-start gap-3 xl:px-3.5 text-sm font-bold transition-all cursor-pointer ${
                  isActive ? 'bg-ember/12 text-ember' : 'text-mut hover:text-ink hover:bg-raise/70'
                }`}
              >
                <span className="relative">
                  <Icon width={20} height={20} />
                  {n.id === 'entrenar' && active && (
                    <span className="pulse-dot absolute -top-1 -right-1 w-2 h-2 rounded-full bg-ember" />
                  )}
                </span>
                <span className="hidden xl:inline">{n.label}</span>
                {isActive && <span className="hidden xl:block absolute right-3 w-1 h-5 rounded-full bg-ember" />}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-line">
          <button
            onClick={() => setOpenSettings(true)}
            className="w-full h-10 rounded-lg flex items-center justify-center xl:justify-start xl:px-3.5 gap-3 text-sm font-bold text-mut hover:text-ink hover:bg-raise/70 transition-colors cursor-pointer"
          >
            <IGear width={19} height={19} />
            <span className="hidden xl:inline">Ajustes</span>
          </button>
        </div>
      </aside>

      {/* nav inferior móvil */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-panel/95 backdrop-blur border-t border-line">
        <div className="grid grid-cols-5 h-[62px]">
          {NAV.map((n) => {
            const Icon = n.icon;
            const isActive = tab === n.id;
            if (n.id === 'entrenar') {
              return (
                <button key={n.id} onClick={() => setTab('entrenar')} className="relative flex items-start justify-center cursor-pointer" aria-label="Entrenar">
                  <span
                    className={`-mt-5 w-13 h-13 rounded-full flex items-center justify-center border-4 border-bg transition-colors ${
                      active ? 'bg-mint text-[#042416]' : 'bg-ember text-[#1c0d04] tick-pulse'
                    }`}
                    style={{ width: 52, height: 52 }}
                  >
                    {active ? <span className="pulse-dot w-2.5 h-2.5 rounded-full bg-[#042416]" /> : <Icon width={22} height={22} strokeWidth={2} />}
                  </span>
                </button>
              );
            }
            return (
              <button
                key={n.id}
                onClick={() => setTab(n.id)}
                className={`flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                  isActive ? 'text-ember' : 'text-mut2'
                }`}
              >
                <Icon width={20} height={20} />
                {n.label}
              </button>
            );
          })}
        </div>
      </nav>

      {/* contenido */}
      <main className="md:pl-[74px] xl:pl-[216px] pb-28 md:pb-12">
        <div className="max-w-[1080px] mx-auto px-4 md:px-8 pt-6 md:pt-9">{children}</div>
      </main>

      <ToastHost />

      {/* ajustes */}
      <Modal open={openSettings} onClose={() => setOpenSettings(false)} title="Ajustes">
        <div className="space-y-6">
          <div>
            <span className="lbl mb-2">Objetivo semanal</span>
            <div className="flex items-center gap-3">
              <Stepper
                value={settings.weeklyGoal}
                onChange={(n) => setSettings({ weeklyGoal: Math.round(n) })}
                step={1}
                min={1}
                max={7}
                className="w-36"
              />
              <span className="text-sm text-mut font-semibold">sesiones por semana</span>
            </div>
          </div>
          <div>
            <span className="lbl mb-2">Descanso por defecto</span>
            <div className="flex items-center gap-3">
              <Stepper
                value={settings.defaultRest}
                onChange={(n) => setSettings({ defaultRest: Math.round(n) })}
                step={15}
                min={30}
                max={420}
                className="w-36"
              />
              <span className="text-sm text-mut font-semibold">{fmtClock(settings.defaultRest)} entre series</span>
            </div>
          </div>

          <div className="border-t border-line pt-5">
            <span className="lbl mb-3">Tus datos</span>
            <div className="grid grid-cols-2 gap-2.5">
              <button onClick={exportData} className="btn btn-ghost px-3 py-2.5 text-xs uppercase tracking-wider">
                <IDownload width={16} height={16} /> Exportar
              </button>
              <button
                onClick={() => fileRef.current?.click()}
                className="btn btn-ghost px-3 py-2.5 text-xs uppercase tracking-wider"
              >
                <IUpload width={16} height={16} /> Importar
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="application/json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) importData(f);
                  e.target.value = '';
                }}
              />
              <button
                onClick={() => {
                  loadSample();
                  setOpenSettings(false);
                }}
                className="btn btn-ghost px-3 py-2.5 text-xs uppercase tracking-wider"
              >
                <IFlame width={16} height={16} /> Datos demo
              </button>
              <button
                onClick={() => {
                  if (!confirmWipe) {
                    setConfirmWipe(true);
                    window.setTimeout(() => setConfirmWipe(false), 3000);
                    return;
                  }
                  clearAll();
                  setConfirmWipe(false);
                  setOpenSettings(false);
                }}
                className={`btn px-3 py-2.5 text-xs uppercase tracking-wider ${confirmWipe ? 'bg-danger text-[#2a0505]' : 'btn-danger'}`}
              >
                <ITrash width={16} height={16} /> {confirmWipe ? '¿Seguro?' : 'Borrar todo'}
              </button>
            </div>
            <p className="text-[11px] text-mut2 mt-3 leading-relaxed">
              Todo se guarda en este dispositivo. Exporta una copia de seguridad si quieres conservar tu historial
              ({sessions.length} {sessions.length === 1 ? 'sesión' : 'sesiones'} actualmente).
            </p>
          </div>
        </div>
      </Modal>
    </div>
  );
}
