import React from 'react';

type P = React.SVGProps<SVGSVGElement>;

const base = (p: P): P => ({
  width: 20,
  height: 20,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  'aria-hidden': true,
  ...p,
});

export const IDumbbell = (p: P) => (
  <svg {...base(p)}>
    <path d="M6.7 6.5v11M17.3 6.5v11M3.4 9.2v5.6M20.6 9.2v5.6M6.7 12h10.6" />
  </svg>
);
export const IHome = (p: P) => (
  <svg {...base(p)}>
    <path d="M3.6 10.6 12 3.6l8.4 7M5.6 9.4V20h12.8V9.4M10 20v-5h4v5" />
  </svg>
);
export const IFlame = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 3.4c.9 2.6 4.6 4.7 4.6 8.7a4.6 4.6 0 0 1-9.2 0c0-1.7.6-3.1 1.6-4.5.4 1.1 1 1.8 1.9 2.2-.4-2.3.1-4.4 1.1-6.4Z" />
  </svg>
);
export const IClock = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.4" />
    <path d="M12 7.6V12l3.1 2" />
  </svg>
);
export const ITrend = (p: P) => (
  <svg {...base(p)}>
    <path d="M3.5 17.5 9 12l3.4 3.4 7.1-7.6M19.5 13.2V7.8h-5.4" />
  </svg>
);
export const IList = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 6.4h1.8M4 12h1.8M4 17.6h1.8M9.2 6.4H20M9.2 12H20M9.2 17.6H20" />
  </svg>
);
export const IPlus = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);
export const IMinus = (p: P) => (
  <svg {...base(p)}>
    <path d="M5 12h14" />
  </svg>
);
export const ICheck = (p: P) => (
  <svg {...base(p)}>
    <path d="m4.8 12.6 4.8 4.8L19.2 7" />
  </svg>
);
export const IX = (p: P) => (
  <svg {...base(p)}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);
export const ITrash = (p: P) => (
  <svg {...base(p)}>
    <path d="M4.6 6.6h14.8M9.6 6.6V4.4h4.8v2.2M6.6 6.6l.8 13h9.2l.8-13M10 10.4v5.2M14 10.4v5.2" />
  </svg>
);
export const IChevD = (p: P) => (
  <svg {...base(p)}>
    <path d="m6 9.5 6 6 6-6" />
  </svg>
);
export const IChevR = (p: P) => (
  <svg {...base(p)}>
    <path d="m9.5 6 6 6-6 6" />
  </svg>
);
export const ICompare = (p: P) => (
  <svg {...base(p)}>
    <path d="M7 4.6 3.6 8 7 11.4M3.6 8h13.2M17 12.6l3.4 3.4-3.4 3.4M20.4 16H7.2" />
  </svg>
);
export const ITrophy = (p: P) => (
  <svg {...base(p)}>
    <path d="M7.2 4.4h9.6v3.4a4.8 4.8 0 0 1-9.6 0V4.4Z" />
    <path d="M7.2 5.4H4.4a2.7 2.7 0 0 0 2.9 2.7M16.8 5.4h2.8a2.7 2.7 0 0 1-2.9 2.7M12 12.6v3M8.4 19.6h7.2M9.8 19.6c0-2.2 1-4 2.2-4s2.2 1.8 2.2 4" />
  </svg>
);
export const ITimer = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="13.4" r="7.2" />
    <path d="M12 9.8v3.6l2.6 1.6M9.6 3.4h4.8M12 3.4v2.2" />
  </svg>
);
export const IPlay = (p: P) => (
  <svg {...base(p)}>
    <path d="M8.4 5.4v13.2L18.6 12 8.4 5.4Z" />
  </svg>
);
export const IRepeat = (p: P) => (
  <svg {...base(p)}>
    <path d="M4.6 9.2a7 7 0 0 1 11.9-2.4l2.3 2.3M18.8 4.6v4.5h-4.5M19.4 14.8a7 7 0 0 1-11.9 2.4l-2.3-2.3M5.2 19.4v-4.5h4.5" />
  </svg>
);
export const IDownload = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 4v10M8.2 10.4l3.8 3.9 3.8-3.9M4.6 19.6h14.8" />
  </svg>
);
export const IUpload = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 14.2V4M8.2 7.7 12 3.9l3.8 3.8M4.6 19.6h14.8" />
  </svg>
);
export const IGear = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="3.1" />
    <path d="M12 4.4v2.1M12 17.5v2.1M4.4 12h2.1M17.5 12h2.1M6.6 6.6l1.5 1.5M15.9 15.9l1.5 1.5M17.4 6.6l-1.5 1.5M8.1 15.9l-1.5 1.5" />
  </svg>
);
export const IBolt = (p: P) => (
  <svg {...base(p)}>
    <path d="M13.2 3.4 5.6 13.4h5.2l-1 7.2 7.6-10h-5.2l1-7.2Z" />
  </svg>
);
export const IKettle = (p: P) => (
  <svg {...base(p)}>
    <path d="M9.2 7a2.8 2.8 0 1 1 5.6 0M7.2 7.2h9.6l1.4 11.6a1.4 1.4 0 0 1-1.4 1.6H7.2a1.4 1.4 0 0 1-1.4-1.6L7.2 7.2Z" />
  </svg>
);
export const IBody = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="7.6" r="3.4" />
    <path d="M5.2 20.4a6.8 6.8 0 0 1 13.6 0" />
  </svg>
);
export const ISearch = (p: P) => (
  <svg {...base(p)}>
    <circle cx="11" cy="11" r="6.4" />
    <path d="m15.8 15.8 4.6 4.6" />
  </svg>
);
export const INote = (p: P) => (
  <svg {...base(p)}>
    <path d="M5 4.4h14v10.8l-4.4 4.4H5V4.4ZM14.6 19.6v-4.4H19" />
  </svg>
);
export const ICalendar = (p: P) => (
  <svg {...base(p)}>
    <rect x="4" y="5.4" width="16" height="14.2" rx="2" />
    <path d="M4 9.6h16M8.2 3.4v3.8M15.8 3.4v3.8" />
  </svg>
);
export const IInfo = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.4" />
    <path d="M12 11v5M12 7.8v.2" />
  </svg>
);
export const IScale = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 4.4v3M6.4 7.4h11.2l1.6 11a1.5 1.5 0 0 1-1.5 1.7H6.3a1.5 1.5 0 0 1-1.5-1.7l1.6-11ZM9 12.6a3 3 0 0 0 6 0" />
  </svg>
);

export const Logo = ({ className = '' }: { className?: string }) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden>
    <rect width="32" height="32" rx="7" fill="#FF6B2C" />
    <path
      d="M9 8v16M23 8v16M5 12v8M27 12v8M9 16h14"
      stroke="#0f1311"
      strokeWidth="2.6"
      strokeLinecap="round"
    />
  </svg>
);
